<?php

namespace App\Http\Controllers;


use App\Invitation;
use Illuminate\Http\Request;

use App\User;
use App\Product;
use App\Category;
use App\Trip;
use App\Bid;
use App\BidComment;
use App\ProductStatus;
use App\Rating;
use App\Notification;
use App\Following;
use App\TripPlace;

use Mockery\CountValidator\Exception;
use Session;
use Auth;
use Validator;
use Redirect;

use Image; // for resize

use Omnipay\Omnipay;

// User Profile and settings
class UserController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }

    public function getHome()
    {

        $user = Auth::user();
        $user_id = $user->id;

        $requests = Product::where('user_id', $user_id)->orderBy('id', 'desc')->limit(5)->get();
        $trips = Trip::where('user_id', $user_id)->orderBy('id', 'desc')->limit(5)->get();


        $bids = Bid::whereHas('product', function ($query) use ($user_id) {
            $query->where('products.user_id', $user_id);
        })->orderBy('product_id', 'desc')->limit(5)->get();

        $applied = Bid::where('user_id', $user_id)->orderBy('product_id', 'desc')->limit(5)->get();

        return view('user.dashboard', ['products' => $requests, 'trips' => $trips, 'bids' => $bids, 'applied' => $applied]);
    }


    public function getRequests()
    {
        $user = Auth::user();
        $user_id = $user->id;

        $countries = config('variables.countries');
        $categories = Category::all()->pluck('category', 'id');

        $products = Product::where('user_id', $user_id)->orderBy('id', 'desc')->get();

        return view('user.requests', ['products' => $products, 'categories' => $categories, 'countries' => $countries]);
    }

    public function getRequest()
    {

        $countries = config('variables.countries');
        $package_sizes = config('variables.package_sizes');
        $delivery_methods = config('variables.delivery_methods');
        $categories = Category::all()->pluck('category', 'id');

        $product = new Product();
        $product->id = 0;
        $product->request_type = 1;
        $product->perishable = 0;
        $product->fragile = 0;

        return view('user.request', ['product' => $product, 'categories' => $categories, 'countries' => $countries, 'package_sizes' => $package_sizes, 'delivery_methods' => $delivery_methods]);
    }

    public function getRequestDuplicate($id)
    {
        $user = Auth::user();
        $user_id = $user->id;

        $countries = config('variables.countries');
        $package_sizes = config('variables.package_sizes');
        $delivery_methods = config('variables.delivery_methods');
        $categories = Category::all()->pluck('category', 'id');

        echo $id;
        $product = Product::findOrFail($id);
        $product->id = 0; // to make a new copy
        $product->user_id = $user_id;

        return view('user.request', ['product' => $product, 'categories' => $categories, 'countries' => $countries, 'package_sizes' => $package_sizes, 'delivery_methods' => $delivery_methods]);
    }

    public function postRequest(Request $request)
    {
        $user = Auth::user();
        $user_id = $user->id;

        $id = $request['id'];
        $photo_old = $request['photo_old'];
        // photo not required for edit, assuming already there
        if ($id == 0 and $photo_old == "") {
            $rules = array('name' => 'required', 'qty' => 'required|numeric', 'description' => 'required', 'category' => 'required', 'photo' => 'required', 'country' => 'required', 'dcity' => 'required', 'dcountry' => 'required', 'price' => 'required|numeric',);
        } else {
            $rules = array('name' => 'required', 'qty' => 'required|numeric', 'description' => 'required', 'category' => 'required', 'country' => 'required', 'dcity' => 'required', 'dcountry' => 'required', 'price' => 'required|numeric',);
        }

        // do the validation ----------------------------------
        // validate against the inputs from our form
        $validator = Validator::make($request->all(), $rules);

        // check if the validator failed -----------------------
        if ($validator->fails()) {

            // get the error messages from the validator
            //$messages = $validator->messages();

            // redirect our user back to the form with the errors from the validator


            if ($id == 0) {
                return Redirect::route('create-request')->withErrors($validator)->withInput();
            } else {
                return Redirect::route('edit-request', $id)->withErrors($validator)->withInput();
            }

        } else {

            if ($id == 0) {
                $product = new Product();
            } else {
                $product = Product::findOrFail($id);
            }

            $product->item_name = $request["name"];
            $product->qty = $request["qty"];
            $product->item_description = $request["description"];
            $product->category_id = $request["category"];
            $product->url = $request["url"];
            $product->country = $request["country"];
            $product->dcity = $request["dcity"];
            $product->dcountry = $request["dcountry"];
            $product->price = $request["price"];
            $product->perishable = $request["perishable"];
            $product->fragile = $request["fragile"];
            $product->package_size = $request["package_size"];
            //$product->delivery_method = $request["delivery_method"];
            $product->status = 'Open'; //$request["type"];

            $product->user_id = $user_id; //$user_id;

            $product->save();

            // getting all of the post images
            $file = $request['photo'];
            $destinationPath = 'uploads/products';
            if ($file) {
                // only jpg files of less than 2MB
                $filename = $file->getClientOriginalName();
                // 5mb
                if ($file->getClientMimeType() == "image/jpeg" and $file->getClientSize() < 5242880) {

                    $fname = $user_id . "-" . $filename;
                    // save image name
                    $product->image = $fname;
                    $product->save();

                    //resize
                    $img = Image::make($file->getRealPath());
                    $img->resize(700, 1000, function ($constraint) {
                        $constraint->aspectRatio();
                        $constraint->upsize();
                    })->save($destinationPath . '/' . $fname);
                    // end of resize
                }
            } else {
                // for duplicate
                if ($id == 0 and isset($request['photo_old']) ) {
                    $product->image = $request['photo_old'];
                    $product->save();
                }
            }

            Session::flash('flash_message', 'Request successfully updated!');

        }

        return redirect()->route('dashboard');

    }

    public function getRequestEdit($id)
    {

        $countries = config('variables.countries');
        $package_sizes = config('variables.package_sizes');
        $delivery_methods = config('variables.delivery_methods');
        $categories = Category::all()->pluck('category', 'id');

        $product = Product::findOrFail($id);

        return view('user.request', ['product' => $product, 'categories' => $categories, 'countries' => $countries, 'package_sizes' => $package_sizes, 'delivery_methods' => $delivery_methods]);

    }

    public function getRequestInvite($id)
    {
        $product = Product::findOrFail($id);
        $country = $product->country;
        $posted_by = $product->user_id; // only user's own requests

        $trips = Trip::where('country', $country)->get(); // add date check
        //$following1 = Following::where('user_id', $posted_by)->get();
        $following2 = Following::where('follow_by', $posted_by)->get();

        return view('user.invite', ['product' => $product, 'trips' => $trips, 'following2' => $following2]);

    }

    public function postRequestInvite(Request $request)
    {

        $product_id = $request['product_id'];
        $check1 = (isset($request['check1']) ? 1 : 0);
        //$check2 = (isset($request['check2']) ? 1 : 0);
        $check3 = (isset($request['check3']) ? 1 : 0);
        $check4 = (isset($request['check4']) ? 1 : 0);
        $emails = $request['emails'];


        $product = Product::findOrFail($product_id);
        $country = $product->country;
        $posted_by = $product->user_id; // only user's own requests
        // trips
        if ($check1) {
            $trips = Trip::where('country', $country)->get(); // add date check

            foreach ($trips as $trip) {
                $user_id = $trip->user_id;
                // check for duplicate
                $invite_count = Invitation::where('product_id', $product_id)->where('user_id', $user_id)->count();
                if ($invite_count == 0) {
                    $invitation = new Invitation();
                    $invitation->product_id = $product_id;
                    $invitation->user_id = $user_id;
                    $invitation->comments = 'Invited';
                    $invitation->save();

                    $notification = new Notification();
                    $notification->description = 'You are invited to place bid on  # .';
                    $notification->user_id = $user_id;
                    $notification->save();

                }
            }
        }

//        if ($check2) {
//            $following1 = Following::where('user_id', $posted_by)->get();
//
//            foreach ($following1 as $f1) {
//                $user_id = $f1->user_id;
//                // check for duplicate
//                $invite_count = Invitation::where('product_id', $product_id)->where('user_id', $user_id)->count();
//                if ($invite_count == 0) {
//                    $invitation = new Invitation();
//                    $invitation->product_id = $product_id;
//                    $invitation->user_id = $user_id;
//                    $invitation->comments = 'Invited';
//                    $invitation->save();
//
//                    $notification = new Notification();
//                    $notification->description = 'You are invited to place bid on  # .';
//                    $notification->user_id = $user_id;
//                    $notification->save();
//
//                }
//            }
//        }

        if ($check3) {
            $following2 = Following::where('follow_by', $posted_by)->get();

            foreach ($following2 as $f2) {
                $user_id = $f2->user_id;
                // check for duplicate
                $invite_count = Invitation::where('product_id', $product_id)->where('user_id', $user_id)->count();
                if ($invite_count == 0) {
                    $invitation = new Invitation();
                    $invitation->product_id = $product_id;
                    $invitation->user_id = $user_id;
                    $invitation->comments = 'Invited';
                    $invitation->save();

                    $notification = new Notification();
                    $notification->description = 'You are invited to place bid on  # .';
                    $notification->user_id = $user_id;
                    $notification->save();

                }
            }
        }

        if ($check4) {
            // for emails

        }


        return redirect()->route('request', $product_id);

    }


    public function getRequestSelect($id)
    {

        $user = Auth::user();
        $user_id = $user->id;

        $bid_id = $id;

        $bid = Bid::findOrFail($id);

        $product = Product::findOrFail($bid->product_id);

        $product->status = 'Awarded';
        $product->save();

        $bid->status = 'Selected';
        $bid->save();

        $product_status = new ProductStatus();
        $product_status->product_id = $product->id;
        $product_status->status = 'Awarded';
        $product_status->status_date = date('Y-m-d H:i:s');
        $product_status->comments = '';
        $product_status->save();

        $notification = new Notification();
        $notification->description = 'Project # awarded to you.';
        $notification->user_id = $bid->user_id;
        $notification->save();

        return redirect()->route('request', $bid->product_id);

    }

    public function getTrip()
    {
        $countries = config('variables.countries');

        $trip = new Trip();
        $trip->trip_type = 'Return';
        $trip->id = 0;

        $trips = array();

        for($a = 0; $a < 4; $a++) {
            $trips[] = [
                "city" => "",
                "country" => "",
                "from_date" => "",
                "upto_date" => ""];
        }

        return view('user.trip', ['trip' => $trip, 'countries' => $countries, 'transit' => $trips]);
    }

    public function postTrip(Request $request)
    {
        $user = Auth::user();
        $user_id = $user->id;

        $rules = array('country' => 'required', 'fromdate' => 'required', 'country_to' => 'required', 'uptodate' => 'required', 'trip_type' => 'required');

        // do the validation ----------------------------------
        // validate against the inputs from our form
        $validator = Validator::make($request->all(), $rules);

        // check if the validator failed -----------------------
        if ($validator->fails()) {

            // get the error messages from the validator
            //$messages = $validator->messages();

            // redirect our user back to the form with the errors from the validator
            return Redirect::route('create-trip')->withErrors($validator)->withInput();

        } else {

            $id = $request["id"];

            if ($id == 0) {
                $trip = new Trip();
            } else {
                $trip = Trip::findOrFail($id);
            }

            $trip->country = $request["country"];
            $trip->from_date = $request["fromdate"];
            $trip->country_to = $request["country_to"];
            $trip->upto_date = $request["uptodate"];
            $trip->trip_type = $request["trip_type"];
            $trip->return_date = $request["returndate"];
            $trip->notes = $request["notes"];

            $trip->user_id = $user_id; //$user_id;

            $trip->save();

            $trip_id = $trip->id;

            for ($a = 0; $a < 4; $a++) {
                $city = $request->city_transit[$a];
                $country = (isset($request->country_transit[$a]) ? $request->country_transit[$a] : null);
                $from_date = $request->fromDate[$a];
                $upto_date = $request->uptoDate[$a];
                if (
                ($city != "" or $city != null) and
                ($country != "" or $country != null) and
                ($from_date != "" or $from_date != null) and
                ($upto_date != "" or $upto_date != null) ) {

                $tp = new TripPlace();
                $tp->trip_id = $trip_id;
                $tp->city = $city;
                $tp->country = $country;
                $tp->from_date = $from_date;
                $tp->upto_date = $upto_date;
                $tp->save();
            }


            }



            Session::flash('flash_message', 'Trip successfully updated!');


        }

        return redirect()->route('dashboard');
    }

    public function getTrips()
    {
        $user = Auth::user();
        $user_id = $user->id;

        $countries = config('variables.countries');

        $trips = Trip::where('user_id', $user_id)->orderBy('id', 'DESC')->get();

        return view('user.trips', ['trips' => $trips, 'countries' => $countries]);
    }

    public function getTripEdit($id)
    {
        $countries = config('variables.countries');

        $trip = Trip::findOrFail($id);

        $trips = TripPlace::where('trip_id', $id)->get()->toArray();
        $ct = count($trips);
        for($a = $ct; $a < 4; $a++) {
            $trips[] = [
                "city" => "",
                "country" => "",
                "from_date" => "",
                "upto_date" => ""];
        }

        return view('user.trip-edit', ['trip' => $trip, 'countries' => $countries, 'transit' => $trips]);
    }

    public function postAddComment(Request $request)
    {

        $user = Auth::user();
        $user_id = $user->id;
        $product_id = $request['id'];

        $rules = array('bid_amount' => 'required|numeric', 'bid_description' => 'required');

        // do the validation ----------------------------------
        // validate against the inputs from our form
        $validator = Validator::make($request->all(), $rules);

        // check if the validator failed -----------------------
        if ($validator->fails()) {

            // get the error messages from the validator
            //$messages = $validator->messages();

            // redirect our user back to the form with the errors from the validator
            return Redirect::route('request', $product_id)->withErrors($validator)->withInput();

        } else {

            $product = Product::findOrFail($product_id);

            $bidcount = Bid::where('user_id', $user_id)->where('product_id', $product_id)->count();

            if ($bidcount == 0) {

                if ($user_id != $product->user_id) {
                    $bid = new Bid();

                    $bid->product_id = $product_id;
                    $bid->user_id = $user_id;
                    $bid->amount = $request["bid_amount"];
                    $bid->comments = $request["bid_description"];
                    $bid->status = "Applied";

                    //TODO image

                    // getting all of the post images
                    $file = $request['attachement'];

                    $destinationPath = 'uploads/comments';
                    if ($file) {
                        // only jpg files of less than 2MB
                        $filename = $file->getClientOriginalName();
                        // 5mb
                        if ($file->getClientMimeType() == "image/jpeg" and $file->getClientSize() < 5242880) {

                            $fname = $user_id . "-" . $filename;
                            // save image name
                            $bid->attachement = $fname;

                            //resize
                            $img = Image::make($file->getRealPath());
                            $img->resize(700, 1000, function ($constraint) {
                                $constraint->aspectRatio();
                                $constraint->upsize();
                            })->save($destinationPath . '/' . $fname);
                            // end of resize
                        }
                    }

                    $bid->save();

                    $notification = new Notification();
                    $notification->description = 'You received a new Bid.';
                    $notification->user_id = $product->user_id;
                    $notification->save();

                    Session::flash('flash_message', 'Bid successfully updated!');
                } else {
                    Session::flash('flash_message', 'You can not bid on your own request!');
                }
            } else {
                Session::flash('flash_message', 'You already placed a bid before for this product!');
            }

        }
        return redirect()->route('request', $product_id);

    }

    public function getInbox()
    {
        $user = Auth::user();

        $user_id = $user->id;

        //$notifications = Notification::where('user_id', $user_id)->orderBy('id', 'desc')->limit(20)->get();

//        \DB::enableQueryLog();

        // old
        //$bid_comments = BidComment::where('user_id', $user_id)->orderBy('id', 'desc')->limit(10)->get();


        $rel_comments =
            BidComment::select(\DB::raw('MAX(id) as id'))
                ->where('user_id', $user_id)
                ->groupBy('bid_id')
                ->orderBy('id', 'DESC')
                ->get()
                ->toArray();

        $ids = array();
        foreach ($rel_comments as $rel_c) {
            $ids[] = $rel_c['id'];
        };

        $bid_comments = BidComment::whereIn('id', $ids)->get();
//        dump(\DB::getQueryLog());
//
//        dump($bid_comments);


        //

//        $bids = Bid::whereExists(function ($query) use($user_id) {
//
//                $query->select("products.user_id")
//
//                      ->from('products')
//
//                      ->whereRaw('products.id = bids.product_id and products.user_id = ' . $user_id);
//
//            })->get();




        return view('user.inbox', ['comments' => $bid_comments]);
    }

    public function getNotification()
    {
        $user = Auth::user();

        $user_id = $user->id;

        $notifications = Notification::where('user_id', $user_id)->orderBy('id', 'desc')->limit(20)->get();

        //$bid_comments = BidComment::where('user_id', $user_id)->orderBy('id', 'desc')->limit(10)->get();

        return view('user.notification', ['notifications' => $notifications]);
    }

    public function getBids()
    {
        $user = Auth::user();

        $user_id = $user->id;


//        \DB::enableQueryLog();

//        $bids = Bid::whereExists(function ($query) use($user_id) {
//
//                $query->select("products.user_id")
//
//                      ->from('products')
//
//                      ->whereRaw('products.id = bids.product_id and products.user_id = ' . $user_id);
//
//            })->get();


        $bids = Bid::whereHas('product', function ($query) use ($user_id) {
            $query->where('products.user_id', $user_id);
        })->orderBy('product_id', 'desc')->get();

//        dump(\DB::getQueryLog());

        return view('user.bids', ['bids' => $bids]);

    }

    public function getApplied()
    {
        $user = Auth::user();

        $user_id = $user->id;


//        \DB::enableQueryLog();

//        $bids = Bid::whereExists(function ($query) use($user_id) {
//
//                $query->select("products.user_id")
//
//                      ->from('products')
//
//                      ->whereRaw('products.id = bids.product_id and products.user_id = ' . $user_id);
//
//            })->get();


//        $bids = Bid::whereHas('product', function ($query) use($user_id) {
//            $query->where('products.user_id', $user_id);
//        })->orderBy('product_id', 'desc')->get();

        $bids = Bid::where('user_id', $user_id)->orderBy('product_id', 'desc')->get();

//        dump(\DB::getQueryLog());

        return view('user.applied', ['bids' => $bids]);

    }

    public function getDiscuss($id)
    {
        $user = Auth::user();
        $bid_id = $id;

        $bid = Bid::findOrFail($bid_id);
        $product_id = $bid->product_id;
        $bid_user = $bid->user_id;
        $bid_comment = $bid->comments;
        $bid_amount = $bid->amount;

        $product = Product::findOrFail($product_id);
        $product_title = $product->item_name;
        $product_user = $product->user_id;

        $comments = BidComment::where('bid_id', $bid_id)->get();

        return view('user.discuss', ['bid' => $bid, 'product' => $product, 'comments' => $comments, 'user_id' => $user->id]);

    }

    public function postDiscuss(Request $request)
    {

        $user = Auth::user();
        $user_id = $user->id;

        $bid_id = $request['bid_id'];

        $bid = Bid::findOrFail($bid_id);
        $bidder_id = $bid->user_id;

        $comments = $request['comment'];

        if ($comments == "" or $comments == null) {
            return redirect()->route('dashboard');
        } else {

            $bidComment = new BidComment();
            $bidComment->bid_id = $bid_id;
            $bidComment->user_id = $user_id;
            if ($user_id == $bidder_id) {
                $bidComment->comment_by = 'Seller';
            } else {
                $bidComment->comment_by = 'Buyer';
            }
            $bidComment->comments = $comments;

            // TODO

            // getting all of the post images
            $file = $request['attachement'];

            $destinationPath = 'uploads/comments';
            if ($file) {
                // only jpg files of less than 2MB
                $filename = $file->getClientOriginalName();
                // 5mb
                if ($file->getClientMimeType() == "image/jpeg" and $file->getClientSize() < 5242880) {

                    $fname = $bid_id . "-" . $filename;
                    // save image name
                    $bidComment->attachement = $fname;

                    //resize
                    $img = Image::make($file->getRealPath());
                    $img->resize(700, 1000, function ($constraint) {
                        $constraint->aspectRatio();
                        $constraint->upsize();
                    })->save($destinationPath . '/' . $fname);
                    // end of resize
                }
            }

            $bidComment->save();

            $notification = new Notification();
            $notification->description = 'You received a new message';
            if ($user_id == $bidder_id) {
                $notification->user_id = $bid->product->user_id;
            } else {
                $notification->user_id = $bid->user_id;
            }
            $notification->save();

            if ($user_id == $bidder_id) {
                // seller
                return redirect()->route('applied');
            } else {
                // buyer
                return redirect()->route('bids');
            }
        }
    }

    public function postUpdateBidStatus(Request $request)
    {
        // updating product and bid statuses
        $user = Auth::user();
        $user_id = $user->id;

        $bid_id = $request['bid_id'];
        $bstatus = $request['status'];

        $bid = Bid::findOrFail($bid_id);
        $product_id = $bid->product_id;

        $product = Product::findOrFail($product_id);

        if ($bstatus == 'Rate') {
            return redirect()->route('get-rating', [$bid->product_id, $bid->id]);
        } else {
            //$bid = Bid::findOrFail($bid_id);

            $product->status = $bstatus;
            $product->save();

            $product_status = new ProductStatus();
            $product_status->product_id = $product_id;
            $product_status->status = $bstatus;
            $product_status->status_date = date('Y-m-d H:i:s');
            $product_status->comments = '';
            $product_status->save();


            $notification = new Notification();
            $notification->description = 'Project status changed.';
            $notification->user_id = $product->user_id;
            $notification->save();

            $notification = new Notification();
            $notification->description = 'Project status changed.';
            $notification->user_id = $bid->user_id;
            $notification->save();

            Session::flash('flash_message', 'Bid status successfully updated!');

            return redirect()->route('request', $bid->product_id);
        }

    }

    public function getWallet()
    {
        $user = Auth::user();
        $user_id = $user->id;

        return view('user.wallet');
    }

    public function getRating($product_id, $bid_id)
    {
        //echo $project_id;
//        echo $bid_id;
//        echo $usertype;

        $user = Auth::user();
        $user_id = $user->id;

        $product = Product::findOrFail($product_id);
        $bid = Bid::findOrFail($bid_id);

        return view('user.rating', ['product' => $product, 'bid' => $bid, 'user_id' => $user_id]);
    }

    public function postRating(Request $request)
    {
        $user = Auth::user();
        $user_id = $user->id;

        $rating = new Rating();

        $rating->product_id = $request['product_id'];
        $rating->bid_id = $request['bid_id'];

        $product = Product::findOrFail($request['product_id']);
        $bid = Bid::findOrFail($request['bid_id']);
        if ($product->user_id == $user_id) {
            $rating_for = $bid->user_id;
            $rating_as = 'Seller';
        } else {
            $rating_for = $product->user_id;
            $rating_as = 'Buyer';
        }

        $rating->rating_by = $user_id; // rating given by
        $rating->user_id = $rating_for; // rating for user
        $rating->rating_as = $rating_as;
        $rating->rating = $request['rating'];
        $rating->review = $request['review'];

        $rating->save();

        Session::flash('flash_message', 'Rating successfully updated!');

        return redirect()->route('request', $product->id);

    }


    public function getProfile($id = 0)
    {
        $user = Auth::user();
        $user_id = $user->id;

        if ($id == 0) $id = $user_id;

        $member = User::findOrFail($id);

        $request_count = Product::where('user_id', $id)->count();

        $bid_count = Bid::where('user_id', $id)->count();

        $review_buyer = Rating::where('user_id', $id)->where('rating_as', 'Buyer')->get();

        $review_seller = Rating::where('user_id', $id)->where('rating_as', 'Seller')->get();

        return view('user.profile', ['member' => $member, 'request_count' => $request_count, 'bid_count' => $bid_count, 'review_buyer' => $review_buyer, 'review_seller' => $review_seller, 'user_id' => $user_id]);

    }

    public function getEditProfile()
    {
        $user = Auth::user();
        $user_id = $user->id;

        $member = User::findOrFail($user_id);

        return view('user.edit-profile', ['member' => $member]);

    }

    public function postEditProfile(Request $request)
    {
        $user = Auth::user();
        $user_id = $user->id;

        $rules = array('name' => 'required', 'email' => 'required|email', 'phone' => 'required', 'about' => 'required',);

        // do the validation ----------------------------------
        // validate against the inputs from our form
        $validator = Validator::make($request->all(), $rules);

        // check if the validator failed -----------------------
        if ($validator->fails()) {

            // get the error messages from the validator
            //$messages = $validator->messages();

            // redirect our user back to the form with the errors from the validator
            return Redirect::route('edit-profile')->withErrors($validator)->withInput();

        } else {

            $member = User::findOrFail($user_id);

            $member->name = $request['name'];
            $member->email = $request['email'];

            $member->phone = $request['phone'];
            $member->about = $request['about'];

            // TODO

            // Image
            // getting all of the post images
            $file = $request['image'];

            $destinationPath = 'uploads/users';
            if ($file) {
                // only jpg files of less than 2MB
                $filename = $file->getClientOriginalName();
                // 5mb
                if ($file->getClientMimeType() == "image/jpeg" and $file->getClientSize() < 5242880) {

                    $fname = $user_id . "-" . $filename;
                    // save image name
                    $member->image = $fname;

                    //resize
                    $img = Image::make($file->getRealPath());
                    $img->resize(300, 300, function ($constraint) {
                        $constraint->aspectRatio();
                        $constraint->upsize();
                    })->save($destinationPath . '/' . $fname);
                    // end of resize
                }
            }


            // TODO - check and update
            if ($request['password'] != "" and $request['password'] == $request['password_confirmation']) {
                $member->password = bcrypt($request['password']);

            }

            $member->save();
            Session::flash('flash_message', 'Profile successfully updated!');
        }
        return redirect()->route('dashboard');
    }

    public function getSettings()
    {
        return view('user.settings');

    }

    public function getFollow($id)
    {
        $user = Auth::user();
        $user_id = $user->id;
        if ($id == $user_id) return redirect()->back();
        // check duplication
        $following = Following::where('user_id', $id)->where('follow_by', $user_id)->count();
        if ($following == 0) {
            $following = new Following();
            $following->user_id = $id;
            $following->follow_by = $user_id;
            $following->save();
            Session::flash('flash_message', 'You are Following this user!');
        }
        return redirect()->back();
    }

    public function getUnFollow($id)
    {
        $user = Auth::user();
        $user_id = $user->id;

        // check duplication
        $following = Following::where('user_id', $id)->where('follow_by', $user_id)->count();

        if ($following > 0) {
            Following::where('user_id', $id)->where('follow_by', $user_id)->delete();
            Session::flash('flash_message', 'You are NOT Following this user!');
        }
        return redirect()->back();

    }

    public function test()
    {

        $gateway = Omnipay::create('AuthorizeNet_CIM');

        $apiLoginId = '644MTyuRtws'; //getenv('AUTHORIZE_NET_API_LOGIN_ID');
        $transactionKey = '693Nv8Rx9b2MmS5t'; //getenv('AUTHORIZE_NET_TRANSACTION_KEY');

        if ($apiLoginId && $transactionKey) {
            $gateway->setDeveloperMode(true);
            $gateway->setApiLoginId($apiLoginId);
            $gateway->setTransactionKey($transactionKey);

            $formData = array('number' => '4242424242424242', 'expiryMonth' => '6', 'expiryYear' => '2018', 'cvv' => '123');

            $createCardOptions = array(
                'email' => "kaylee@serenity.com",
                'card' => $formData,
                'testMode' => true,
                'forceCardUpdate' => true
            );

            try {

                $responseCard = $gateway->createCard($createCardOptions)->send();

                echo $responseCard->getMessage();
                $cardRef = $responseCard->getCardReference();

                echo 'card';


            } catch (\InvalidCreditCardException $e) {
                exit ('card error');
            } catch (\Exception $e) {

                exit ('error' . $e->getMessage());
            };


            try {

                $response = $gateway->purchase(array('amount' => '10.00', 'currency' => 'USD', 'cardReference' => $cardRef))->send();

            } catch (\Exception $e) {
                exit ('purchase error');
            }


            echo 'response';
            //$response = $gateway->purchase(array('amount' => '10.00', 'currency' => 'USD', 'card' => $formData));


            if ($response->isRedirect()) {
                // redirect to offsite payment gateway
                $response->redirect();
            } elseif ($response->isSuccessful()) {
                // payment was successful: update database

                echo $response->getMessage();

                $res = $response->getTransactionReference();
                //echo $res->getTransId();
                echo $res;
                echo gettype($res);

                $x = json_decode($res, true);

                echo $x['approvalCode'];
                echo $x['transId'];

            } else {
                // payment failed: display message to customer
                echo 'error';
                echo $response->getMessage();
            }

        } else {
            // No credentials were found, so skip this test
            $this->markTestSkipped();
        }


    }

    public function test2()
    {

        $gateway = Omnipay::create("PayPal_Express");
        $gateway->setUsername('aa.merchant_api1.gmail.com'); //$this->USERNAME );
        $gateway->setPassword('V27QA646D9B84K3P'); //$this->PASSWORD );
        $gateway->setSignature('AFcWxV21C7fd0v3bYYYRCpSSRl31Ay93LLjsXddNXQmxsuJay28zjxck'); //$this->SIGNATURE );
        $gateway->setTestMode(true);

        $params = [
            //'transactionId' => 1,
            'amount' => '10.00',
            'currency' => 'USD',
            'cancelUrl' => 'http://xxxx.com/paypal_tests/cancel',
            'returnUrl' => 'http://xxxx.com/paypal_tests/confirm_paypal',
            'notifyUrl' => ''
        ];

        $response = $gateway->purchase($params)->send();


        if ($response->isRedirect()) {

            echo 'Redirect';
            echo $response->getMessage();

            $response->redirect();

        }

        if ($response->isSuccessful()) {
            echo 'Success';
            echo $response->getTransactionReference();
            echo $response->getMessage();
        }
    }
}