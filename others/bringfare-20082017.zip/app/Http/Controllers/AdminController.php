<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\User;
use App\Product;
use App\Category;
use App\Trip;
use App\Bid;
use App\BidComment;
use App\BidStatus;
use App\Rating;

use Session;
use Auth;
use Validator;
use Redirect;

use Image; // for resize


class AdminController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth:admin');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // dashboard
        return view('admin');
    }

    public function getProducts() {

        $adminuser = Auth::guard('admin')->user();
        $user_id = $adminuser->id;

        $countries = config('variables.countries');
        $categories = Category::all()->pluck('category', 'id');

        $products = Product::orderBy('id', 'desc')->paginate(5);

        return view('admin.products', ['products' => $products]);

    }

    public function getProduct($id) {
        $adminuser = Auth::guard('admin')->user();
        $user_id = $adminuser->id;

        $product = Product::findOrFail($id);

        $bids = Bid::where('product_id', $id)->get();


        return view('admin.request', ['product' => $product, 'bids' => $bids]);
    }

    public function getUsers() {

        $adminuser = Auth::guard('admin')->user();
        $user_id = $adminuser->id;

        $users = User::orderBy('id', 'desc')->paginate(5);

        return view('admin.users', ['users' => $users]);
    }

    public function getUser($id) {
        $adminuser = Auth::guard('admin')->user();
        $user_id = $adminuser->id;

        $user = User::findOrFail($id);

        $products = Product::where('user_id', $id)->get();
        $bids = Bid::where('user_id', $id)->get();

        return view('admin.user', ['products' => $products, 'bids' => $bids, 'user' => $user]);
    }

    public function getCategories() {

        $adminuser = Auth::guard('admin')->user();
        $user_id = $adminuser->id;

        $categories = Category::orderBy('id', 'desc')->paginate(5);

        return view('admin.categories', ['categories' => $categories]);
    }

}
