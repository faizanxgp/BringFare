<?php $__env->startSection('title'); ?>
	Admin Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageHeading'); ?>
	User Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


	<section id="main-slider">
		<h1>Your Middleman To Shop With A Peace Of Mind</h1>
		<h3>1000+ Travellors | 5000+ Members | 10000+ Requests</h3>
		<div class="box">
			<h4>GET STARTED</h4>
			<div class="one inline">
				<h5>BROWSE</h5>
				<a href="" class="btn btn-secondary">Trip</a> <a href="" class="btn btn-primary">Request</a>
			</div>
			<div class="one inline">
				<h5>POST</h5>
				<a href="" class="btn btn-secondary">Trip</a> <a href="" class="btn btn-primary">POST</a>

			</div>
		</div>

	</section>

	<section id="page">

		<section class="main-page">
			<div class="container bordbott">
				<div class="row">
					<div class="col-md-6">
						<h2 class="title">Why Use BringFare?</h2>
						<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec,
							pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim.
						</p>
						<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec,
							pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim.
						</p>
					</div>
					<div class="col-md-5 col-md-push-1">
						<div class="customer-reviews">
							<h2><img src="<?php echo e(URL::to('src/images/icons/icon-reviews.png ')); ?>" /> Customer Reviews </h2>
							<div class="reviews owl-carousel owl-theme">
								<div class="cardx">
									<div class="review-item">
										<div class="user-img inline"><img src="<?php echo e(URL::to('src/images/users/user1.jpg')); ?>" alt=""/></div>
										<div class="user-details inline"><a href="#">myusername</a>
											<div class="user-stars"><img src="<?php echo e(URL::to('src/images/stars.png')); ?>" alt=""/></div>
										</div>

										<div class="review-details">To traveller lux-ex for helping to buy To traveller lux-ex for helping to buy To traveller lux-ex for helping to buy </div>
									</div>
								</div>
								<div class="cardx">
									<div class="review-item">
										<div class="user-img inline"><img src="<?php echo e(URL::to('src/images/users/user1.jpg')); ?>" alt=""/></div>
										<div class="user-details inline"><a href="#">myusername</a>
											<div class="user-stars"><img src="<?php echo e(URL::to('src/images/stars.png')); ?>" alt=""/></div>
										</div>

										<div class="review-details">To traveller lux-ex for helping to buy To traveller lux-ex for helping to buy To traveller lux-ex for helping to buy </div>
									</div>
								</div>
								<div class="cardx">
									<div class="review-item">
										<div class="user-img inline"><img src="<?php echo e(URL::to('src/images/users/user1.jpg')); ?>" alt=""/></div>
										<div class="user-details inline"><a href="#">myusername</a>
											<div class="user-stars"><img src="<?php echo e(URL::to('src/images/stars.png')); ?>" alt=""/></div>
										</div>

										<div class="review-details">To traveller lux-ex for helping to buy To traveller lux-ex for helping to buy To traveller lux-ex for helping to buy </div>
									</div>
								</div>
								<div class="cardx">
									<div class="review-item">
										<div class="user-img inline"><img src="<?php echo e(URL::to('src/images/users/user1.jpg')); ?>" alt=""/></div>
										<div class="user-details inline"><a href="#">myusername</a>
											<div class="user-stars"><img src="<?php echo e(URL::to('src/images/stars.png')); ?>" alt=""/></div>
										</div>

										<div class="review-details">To traveller lux-ex for helping to buy To traveller lux-ex for helping to buy To traveller lux-ex for helping to buy </div>
									</div>
								</div>
							</div>


						</div>
					</div>
				</div>
			</div>


			
				
					

					

					
						
							
							
								
									
										
											
											
											
										
										
											
											
										
									
								
								
									
										
											
											
											
										
										
											
											
										
									
								
								
									
										
											
											
											
										
										
											
											
										
									
								
								
									
										
											
											
											
										
										
											
											
										
									
								
								
									
										
											
											
											
										
										
											
											
										
									
								


							


						
					


				
			
		</section>
		

			
				
					
						
					
					
						
					
					
						
					
					
						
					
					
						
					
					
						
					
					
						
					
				
			
		
		
			
				
					
						
						
						
						
						
						
						
						
						

					
				
			


			

		
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>