<?php $__env->startSection('title'); ?>
	Admin Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageHeading'); ?>
	User Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<section id="page" class="header-margin">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<h2><i class="fa fa-envelope"></i> Products </h2>
				</div>

				<div class="col-md-12">
					<h3 class="inline"><i class="fa fa-comments-o"></i> Messages </h3>
					<div class="filterby">Filter by <select></select></div>
					<table class="table messages">
						<tr>
							<th>Product</th>
							<th>User</th>
							<th>Date</th>
							<th>Action</th>
						</tr>
						<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><a class="" href="<?php echo e(route('admin.product', $product->id)); ?>"><?php echo e($product->item_name); ?></a></td>
								<td><a href="#"><?php echo e($product->user->name); ?></a></td>
								<td><?php echo e($product->created_at); ?></td>
								<td><a href="" class="btn btn-primary">Edit</a></td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td colspan="4"><?php echo e($products->links()); ?></td>
						</tr>
					</table>
				</div>
			</div>
		</div>
	</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>