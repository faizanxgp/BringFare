<?php $__env->startSection('title'); ?>
	Admin Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageHeading'); ?>
	User Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<section id="page-inner" class="header-margin">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<?php if(Session::has('flash_message')): ?>
						<div class="alert alert-success">
							<?php echo e(Session::get('flash_message')); ?>

						</div>
					<?php endif; ?>
					<h2><i class="fa fa-envelope"></i> Dashboard </h2>
					<?php echo $__env->make('partials.sub-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


				</div>
				
				
					
					


					

					
						
							
							
							
						
						
							
								
								
								
							
						
					
				
				
					
					
					
					
						
							
							
							
							
							
						
						
							
								
								
								
								
								
							
						
					
				
				
				
				
					
					
					
					
						
							
							
							
							
						
						
							
								
								
								
								
							
						
					

				
				
					
					
					
					
						
							
							
							
							
						
						
							
								
								
								
								
							
						
					
				
				
			</div>
		</div>


	</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>