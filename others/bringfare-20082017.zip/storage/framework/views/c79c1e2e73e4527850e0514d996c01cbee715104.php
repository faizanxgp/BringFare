<?php $__env->startSection('title'); ?>
	Admin Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageHeading'); ?>
	User Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<section id="page-inner" class="header-margin">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<h2><i class="fa fa-envelope"></i> Requests </h2>
					<?php echo $__env->make('partials.sub-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				</div>
				<div class="col-md-12">
					<h3 class="inline"><i class="fa fa-list-ul"></i> Activities </h3>
					<div class="filterby">Filter by <select></select></div>

					<table class="table">
						<tr>
							<th>Product</th>
							<th>Category</th>
							<th>Price</th>
							<th>Country</th>
							<th>Status</th>
							<th>Date/Time</th>
							<th>Action</th>
						</tr>
						<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


							<tr>
								<td><a href="<?php echo e(route('request', $product->id)); ?>"><?php echo e($product->item_name); ?></a></td>
								<td><?php echo e($product->category->category); ?></td>
								<td><?php echo e($product->price); ?></td>
								<td><?php echo e($product->country); ?></td>
								<td><?php echo e($product->status); ?></td>
								<td><?php echo e($product->created_at); ?></td>

								<td><a class="btn btn-primary" href="<?php echo e(route('bids')); ?>">Bids</a> <a class="btn btn-primary" href="<?php echo e(route('edit-request', $product->id)); ?>">Edit</a> <a class="btn btn-danger btn-delete" href="<?php echo e(route('edit-request', $product->id)); ?>">Delete</a></td>

							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</table>
					<p><a href="<?php echo e(route('create-request')); ?>" class="btn btn-primary">Post Request</a></p>
				</div>

			</div>
		</div>


	</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
	<script>


		$(document).ready(function() {
			$('.btn-delete').click(function(e) {
				e.preventDefault();

				var linkURL = $(this).attr("href");
				console.log(linkURL);

				warnBeforeRedirect(linkURL);
			});

			function warnBeforeRedirect(linkURL) {
				swal({
					title: "Are you sure?",
					text: "Do you really want to delete this item?",
					type: "warning",
					showCancelButton: true,
					confirmButtonColor: '#3085d6',
					cancelButtonColor: '#d33',
					confirmButtonText: 'Yes, delete it!'

				}).then(function () {
					console.log('done');
					window.location.href = linkURL;
				});
//
//
//
//
//				, function() {
//					window.location.href = linkURL;
//				});
			}
		});


//		$( document ).ready(function() {
//
//
//		$('.btn-delete').click(
//	swal({
//		title: 'Are you sure?',
//		text: "You won't be able to revert this!",
//		type: 'warning',
//		showCancelButton: true,
//		confirmButtonColor: '#3085d6',
//		cancelButtonColor: '#d33',
//		confirmButtonText: 'Yes, delete it!'
//	}).then(function () {
//		swal(
//		'Deleted!',
//		'Your file has been deleted.',
//		'success'
//		)
//	})
//		)
//
//
//		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>