<?php $__env->startSection('title'); ?>
	Admin Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageHeading'); ?>
	User Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<section id="page" class="header-margin">
		<div class="container">
			<div class="row request-title">
				<div class="col-md-12">
					<?php if(Session::has('flash_message')): ?>
						<div class="alert alert-success">
							<?php echo e(Session::get('flash_message')); ?>

						</div>
					<?php endif; ?>

				</div>
			</div>
			<div class="row request-section">
				<div class="col-md-12 ">
					<div class="row request-details">
						<div class="col-md-6">

							<h1><?php echo e($product->item_name); ?> <?php echo e($product->id); ?> (<?php echo e($product->status); ?>)</h1>



							<div class="product-img card">
								<?php if($product->image == ""): ?>
									<img src="<?php echo e(URL::to('src/images/items/item-default.jpg')); ?>" alt=""/>
								<?php else: ?>

									<img src="<?php echo e(URL::to('/uploads/products/' . $product->image)); ?>" alt=""/>
								<?php endif; ?>
								<?php echo e($product->image); ?>

							</div>


							<div class="details">

								<strong>Descriptin:</strong>
								<div class="mb20">
									<?php echo e($product->item_description); ?>

								</div>

								<p><i class="fa fa-shopping-bag"></i> Quantity <?php echo e($product->qty); ?></p>
								<p><i class="fa fa-map-marker"></i> Shop in <?php echo e($product->country); ?></p>

								<p><i class="fa fa-map-marker"></i> Deal in PAKISTAN</p>
								<p><i class="fa fa-tag"></i> Willing to pay <?php echo e($product->price); ?> USD</p>
								<div class="user-details">
									<b>Requested by </b><br/><br/>
									<div class="user-img inline"><img class="img-circle user-img1" src="<?php echo e(URL::to('src/images/users/user1.jpg')); ?>" alt=""/></div>
									<div class="title-img inline"><a href=""><?php echo e($product->user->name); ?> </a><br/>Start <br/>(8 reviews)</div>
								</div>

							</div>

						</div>

						<div class="col-md-6">
							<div class="comments ">
								<h3>Comments</h3>
								<div class="separator"></div>
								<?php if( !$bids->isEmpty() ): ?>
									<?php $__currentLoopData = $bids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<div class="comment row">
											<div class="user-img inlinex col-md-2"><img class="img-circle user-img10" src="<?php echo e(URL::to('src/images/users/user1.jpg')); ?>" alt=""/></div>
											<div class="comment-body inlinex col-md-10">
												<div class="one"><a href=""><?php echo e($bid->user->name); ?> (star ratings) (success rate)</a> Posted On: Date <span class="pull-right"><strong>Offer Amount: $ <?php echo e($bid->amount); ?></strong></span></div>
												<div class="two"><?php echo e($bid->comments); ?></div>

												<div class="edit-bid">
													<br/>

														<button class="btn btn-success"><?php echo e($bid->status); ?></button> <button class="btn btn-success">View Discussion</button>



												</div>


												
												
												


											</div>
										</div>

									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php else: ?>

									<p>No comments yet</p>
								<?php endif; ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<div id="myModal" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					<h4 class="modal-title">BringFare</h4>
				</div>
				<div class="modal-body">
					<p>Loading...</p>
				</div>
				<div class="modal-footer">

				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
	<script>
		jQuery('.ls-modal').on('click', function (e) {
			e.preventDefault();
			jQuery('#myModal').modal('show').find('.modal-body').load(jQuery(this).attr('href'));
		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>