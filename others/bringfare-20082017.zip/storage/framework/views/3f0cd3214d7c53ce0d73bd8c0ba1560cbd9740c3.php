<?php $__env->startSection('title'); ?>
	Admin Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageHeading'); ?>
	User Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<section id="page" class="header-margin">
		<div class="container">

			<div class="row">
				<div class="col-md-3 sidebar">
					

					<form method="post" action="<?php echo e(route('post-search-trips')); ?>">

						<label> From Country: </label>

						<div class="form-group">
							<?php echo e(Form::select('f_country', $countries, null, ['class' => 'form-control', 'placeholder' => 'Please select...', ''])); ?>

						</div>

						<label> To Country <span class="required">*</span> : </label>

						<div class="form-group">
							<?php echo e(Form::select('t_country', $countries, null, ['class' => 'form-control', 'placeholder' => 'Please select...', 'required'])); ?>

						</div>

						<label> From Date: </label>

						<div class="form-group ">
							<input type="text" id="datepicker1" name="from_date" class="form-control" placeholder="YYYY-MM-DD"/>
						</div>

						<label> To Date: </label>

						<div class="form-group ">
							<input type="text" id="datepicker2" name="upto_date" class="form-control" placeholder="YYYY-MM-DD"/>
						</div>

						<div class="form-group ">
							<input type="submit" class="btn btn-primary"/>
							<?php echo e(csrf_field()); ?>

						</div>

					</form>


				</div><!-- .sidebar -->
				<div class="col-md-9">

					<div class="search-results">
						<div class="row">
							<?php $__currentLoopData = $trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="col-md-4">
									<div class="item-card card">
										<div class="card-top">

											<div class="item-title"><?php echo e($trip->country); ?> - <?php echo e($trip->country_to); ?></div>
											<div class="item-status"><label class="label label-primary"><?php echo e($trip->from_date); ?> to <?php echo e($trip->upto_date); ?></label></div>

										</div>
										<div class="card-footer">
											<div class="user-img inline"><img src="<?php echo e(URL::to('src/images/users/user1.jpg')); ?>" alt=""/></div>
											<div class="title-img inline"><a href=""><?php echo e($trip->user->name); ?></a></div>
										</div>
									</div>
								</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

							<div class="col-md-4">
								<div class="item-card card">
									<div class="card-top">
										<div class="image"><a href="#"><img src="<?php echo e(URL::to('src/images/items/item1.jpg')); ?>" alt=""/></a></div>
										<div class="item-title">item name</div>
										<div class="item-status"><label class="label label-primary">Open</label></div>
									</div>
									<div class="card-footer">
										<div class="user-img inline"><img src="<?php echo e(URL::to('src/images/users/user1.jpg')); ?>" alt=""/></div>
										<div class="title-img inline">Buy in JAPAN<br/>Willing to pay SGD 1000</div>
									</div>
								</div>
							</div>
						</div>
					</div><!-- .search-results -->

				</div>
			</div>

		</div>


	</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>