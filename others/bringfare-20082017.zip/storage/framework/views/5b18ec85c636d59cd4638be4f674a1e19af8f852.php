<?php $__env->startSection('title'); ?>
	Admin Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageHeading'); ?>
	User Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<section id="page" class="header-margin">
		<div class="container">
			<div class="row">
				<div class="col-md-3 sidebar">

					<div class="search-form">
						<form method="post" action="<?php echo e(route('post-search')); ?>">
							<div class="searchBox">
								<h3>Categories <a class="showHide pull-right"><i class="fa fa-plus-circle"></i></a></h3>
								<div class="options-box" style="display: none;">
									<ul class="nostyle">
										<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<li>
												<input type="checkbox" name="category[]" value="<?php echo e($category->id); ?>"> <?php echo e($category->category); ?>

											</li>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</ul>
								</div>
							</div>
							<div class="searchBox">
								<h3>Purchase From <a class="showHide pull-right"><i class="fa fa-plus-circle"></i></a></h3>
								<div class="options-box" style="display: none;">
									<?php echo e(Form::select('country', $countries, $search['country'] or null, ['class' => 'form-control', 'placeholder' => 'Please select...', 'id' => 'country'])); ?>

								</div>
							</div>

							<div class="searchBox">
								<h3>Deliver in <a class="showHide pull-right"><i class="fa fa-plus-circle"></i></a></h3>
								<div class="options-box" style="display: none;">
									<?php echo e(Form::select('d_country', $countries, $search['dcountry'] or null, ['class' => 'form-control', 'placeholder' => 'Please select...', 'id' => 'dcountry'])); ?>


									<input type="text" class="form-control" name="dcity" value="<?php echo e(isset($search['dcity']) ? $search['dcity'] : null); ?>" placeholder="City" />
								</div>
							</div>

							<div class="searchBox">
								<h3>Price Range <a class="showHide pull-right"><i class="fa fa-plus-circle"></i></a></h3>
								<div class="options-box" style="display: none;">
									<p>
										<label for="amount">Price range:</label>
										<input type="text" id="amount" readonly style="border:0; color:#f6931f; font-weight:bold;">
										<input type="hidden" id="price1" name="price1" value="<?php echo e(isset($search['price1']) ? $search['price1'] : 0); ?>" />
										<input type="hidden" id="price2" name="price2" value="<?php echo e(isset($search['price2']) ? $search['price2'] : 1000); ?>" />
									</p>

									<div id="slider-range"></div>


								</div>
							</div>

							<div class="searchBox">
								<h3>Deliver before <a class="showHide pull-right"><i class="fa fa-plus-circle"></i></a></h3>
								<div class="options-box" style="display: none;">
									<ul class="nostyle">
										<li>
											<label>Date</label> <input type="text" name="before_date" value="" id="datepicker1">
										</li>

									</ul>
								</div>
							</div>

							<div class="searchBox">
								<h3>Package size <a class="showHide pull-right"><i class="fa fa-plus-circle"></i></a></h3>
								<div class="options-box" style="display: none;">
									<ul class="nostyle">
										<li>
											<?php echo e(Form::select('package_size', $package_sizes, null, ['class' => 'form-control', 'placeholder' => 'Please select...'])); ?>


										</li>

									</ul>
								</div>
							</div>

							<div class="searchBox">
								<h3>Request by people you follow <a class="showHide pull-right"><i class="fa fa-plus-circle"></i></a></h3>
								<div class="options-box" style="display: none;">
									<ul class="nostyle">
										<li>
											<input type="checkbox" name="followers" value="1"> My Followers
										</li>

									</ul>
								</div>
							</div>


							<div class="form-group2">
								
									
										
											
												
												
												
												
											
										
									
									
										
											
										
									

								
								
									
									
										
											
											
										
									

									
										
									


								
								

									
									
									
									


								

								<div class="searchButton inline">
									<div class="input-group">
										<input class="form-control btn-primary" type="submit" value="Search">
										<?php echo e(csrf_field()); ?>

									</div>
								</div>

							</div>
						</form>
					</div><!-- .search-form -->


					
					
						
							
						

					
				</div><!-- .sidebar -->
				<div class="col-md-9">


					<div class="search-results">
						<div class="row">
							<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="col-md-4">
									<div class="item-card card">
										<div class="card-top">
											<div class="image"><a href="#"><?php if($product->image): ?> <img src="<?php echo e(URL::to('/uploads/products/' . $product->image)); ?>" alt=""/><?php else: ?> <img src="<?php echo e(URL::to('src/images/items/item1.jpg')); ?>" alt=""/> <?php endif; ?></a></div>
											<div class="item-title"><a href="<?php echo e(route('request', $product->id)); ?>"><?php echo e($product->item_name); ?></a></div>
											<div class="item-status"><label class="label label-primary"><?php echo e($product->status); ?></label></div>

										</div>
										<div class="card-footer">
											<div class="user-img inline"><img src="<?php echo e(URL::to('src/images/users/user1.jpg')); ?>" alt=""/></div>
											<div class="title-img inline">Buy in <?php echo e($product->country); ?><br/>at USD <?php echo e($product->price); ?> <br />Deliver in <?php echo e($product->dcity); ?>, <?php echo e($product->dcountry); ?> <?php if($product->require_date != null): ?> before <?php echo e($product->require_date); ?><?php endif; ?> </div>
										</div>
									</div>
								</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

							<div class="col-md-4">
								<div class="item-card card">
									<div class="card-top">
										<div class="image"><a href="#"><img src="<?php echo e(URL::to('src/images/items/item1.jpg')); ?>" alt=""/></a></div>
										<div class="item-title">item name</div>
										<div class="item-status"><label class="label label-primary">Open</label></div>
									</div>
									<div class="card-footer">
										<div class="user-img inline"><img src="<?php echo e(URL::to('src/images/users/user1.jpg')); ?>" alt=""/></div>
										<div class="title-img inline">Buy in JAPAN<br/>Willing to pay SGD 1000</div>
									</div>
								</div>
							</div>
						</div>
					</div><!-- .search-results -->

				</div>
			</div>

		</div>


	</section>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
	<script>
		$(document).ready(function () {
			$('.showHide').click(function (e) {
				e.preventDefault();
				link = $(this).find("i.fa");
				console.log(link);
				if (link.hasClass('fa-plus-circle')) {
					link.addClass('fa-minus-circle');
					link.removeClass('fa-plus-circle');
				} else {
					link.addClass('fa-plus-circle');
					link.removeClass('fa-minus-circle');
				}

				$(this).parent().parent().find("div.options-box").toggle(1000);

			});

			price1 = <?php echo e(isset($search['price1']) ? $search['price1'] : 0); ?>;
			price2 = <?php echo e(isset($search['price2']) ? $search['price2'] : 1000); ?>;


			$( "#amount" ).val( "$" + price1 + " - $" + price2 );
		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>