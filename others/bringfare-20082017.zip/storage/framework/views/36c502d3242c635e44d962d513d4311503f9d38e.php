<?php $__env->startSection('title'); ?>
	Admin Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageHeading'); ?>
	User Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<section id="page-inner" class="header-margin">
		<div class="container">
			<form method="post" action="<?php echo e(route('add-trip')); ?>">
				<div class="row">
					<div class="col-md-10 col-md-push-1">
						<h2><i class="fa fa-plane"></i> Post Trip </h2>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group <?php echo e($errors->has('country') ? ' has-error' : ''); ?>">
									<div class="">
										<label>From Country </label> <?php echo e(Form::select('country', $countries, $trip->country or old('country'), ['placeholder' => 'Please select...', 'class' => 'form-control', 'id' => 'country'])); ?>

										<?php if($errors->has('country')): ?>
											<span class="help-block">
												<strong><?php echo e($errors->first('country')); ?></strong>
											</span>
										<?php endif; ?>
									</div>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group <?php echo e($errors->has('fromdate') ? ' has-error' : ''); ?>">
									<div class="">
										<label>From </label> <input name="fromdate" class="form-control" type="text" placeholder="YYYY-MM-DD" value="<?php echo e(isset($trip->from_date) ? $trip->from_date : old('fromdate')); ?>" id="datepicker1"/>
										<?php if($errors->has('fromdate')): ?>
											<span class="help-block">
                            			<strong><?php echo e($errors->first('fromdate')); ?></strong>
                          			</span>
										<?php endif; ?>
									</div>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group <?php echo e($errors->has('country_to') ? ' has-error' : ''); ?>">
									<div class="">
										<label>To Country </label> <?php echo e(Form::select('country_to', $countries, $trip->country_to or old('country_to'), ['placeholder' => 'Please select...', 'class' => 'form-control', 'id' => 'dcountry'])); ?>

										<?php if($errors->has('country_to')): ?>
											<span class="help-block">
												<strong><?php echo e($errors->first('country_to')); ?></strong>
											</span>
										<?php endif; ?>
									</div>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group <?php echo e($errors->has('uptodate') ? ' has-error' : ''); ?>">
									<div class="">
										<label>Upto</label> <input name="uptodate" class="form-control" type="text" placeholder="YYYY-MM-DD" value="<?php echo e(isset($trip->upto_date) ? $trip->upto_date : old('uptodate')); ?>" id="datepicker2"/>
										<?php if($errors->has('uptodate')): ?>
											<span class="help-block">
                            			<strong><?php echo e($errors->first('uptodate')); ?></strong>
                          			</span>
										<?php endif; ?>
									</div>
								</div>

							</div>
						</div>
						<div class="row">
							<div class="col-md-3">
								<div class="form-group">
									<div class="">
										<label>Trip Type</label><br/> <label><input type="radio" name="trip_type" value="Return" <?php echo e(($trip->trip_type == 'Return' ? 'checked' : '')); ?>> Return </label> <label><input type="radio" name="trip_type"
													value="One Way" <?php echo e(($trip->trip_type == 'One Way' ? 'checked' : '')); ?>> One Way </label>
									</div>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<div class="">
										<label>Return Date</label> <input name="returndate" class="form-control datepickerfield" type="text" placeholder="YYYY-MM-DD" value="<?php echo e(isset($trip->return_date) ? $trip->return_date : old('returndate')); ?>"/>
										<?php if($errors->has('returndate')): ?>
											<span class="help-block">
                            			<strong><?php echo e($errors->first('returndate')); ?></strong>
                          			</span>
										<?php endif; ?>
									</div>

								</div>
							</div>
							<div class="col-md-6">

								<div class="form-group <?php echo e($errors->has('notes') ? ' has-error' : ''); ?>">
									<div class="">
										<label>Visit Description</label> <textarea name="notes" class="form-control" placeholder="Describe your visit details, cities etc"><?php echo e(isset($trip->notes) ? $trip->notes : old('notes')); ?></textarea>
										<?php if($errors->has('notes')): ?>
											<span class="help-block">
                            			<strong><?php echo e($errors->first('notes')); ?></strong>
                          			</span>
										<?php endif; ?>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="addLocations col-md-12">
						<div class="row">
							<div class="col-md-12">
								<h3>Transit Stops</h3>

							</div>
						</div>
						<div class="row">
							<div class="col-md-3">
								<div class="form-group">
									<label>City</label> <input type="text" class="form-control" name="city_transit[]" value="<?php echo e(isset($transit[0]['city']) ? $transit[0]['city'] : ''); ?>"/>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label>Country</label>
									<?php echo e(Form::select('country_transit[]', $countries, $transit[0]['country'] or '', ['placeholder' => 'Please select...', 'class' => 'form-control'])); ?>

								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label>Return Date</label> <input name="fromDate[]" class="form-control datepickerfield" type="text" placeholder="YYYY-MM-DD" value="<?php echo e($transit[0]['from_date']); ?>"/>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label>Return Date</label> <input name="uptoDate[]" class="form-control datepickerfield" type="text" placeholder="YYYY-MM-DD" value="<?php echo e($transit[0]['upto_date']); ?>"/>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-3">
								<div class="form-group">
									<label>City</label> <input type="text" class="form-control" name="city_transit[]" value="<?php echo e(isset($transit[1]['city']) ? $transit[1]['city'] : ''); ?>"/>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label>Country</label>
									<?php echo e(Form::select('country_transit[]', $countries, $transit[1]['country'] or null, ['placeholder' => 'Please select...', 'class' => 'form-control'])); ?>

								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label>Return Date</label> <input name="fromDate[]" class="form-control datepickerfield" type="text" placeholder="YYYY-MM-DD" value="<?php echo e($transit[1]['from_date']); ?>"/>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label>Return Date</label> <input name="uptoDate[]" class="form-control datepickerfield" type="text" placeholder="YYYY-MM-DD" value="<?php echo e($transit[1]['upto_date']); ?>"/>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-3">
								<div class="form-group">
									<label>City</label> <input type="text" class="form-control" name="city_transit[]" value="<?php echo e(isset($transit[2]['city']) ? $transit[2]['city'] : ''); ?>"/>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label>Country</label>
									<?php echo e(Form::select('country_transit[]', $countries, $transit[2]['country'] or '', ['placeholder' => 'Please select...', 'class' => 'form-control'])); ?>

								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label>Return Date</label> <input name="fromDate[]" class="form-control datepickerfield" type="text" placeholder="YYYY-MM-DD" value="<?php echo e($transit[2]['from_date']); ?>"/>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label>Return Date</label> <input name="uptoDate[]" class="form-control datepickerfield" type="text" placeholder="YYYY-MM-DD" value="<?php echo e($transit[2]['upto_date']); ?>"/>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-3">
								<div class="form-group">
									<label>City</label> <input type="text" class="form-control" name="city_transit[]" value="<?php echo e(isset($transit[3]['city']) ? $transit[3]['city'] : ''); ?>"/>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label>Country</label>
									<?php echo e(Form::select('country_transit[]', $countries, $transit[3]['country'] or '', ['placeholder' => 'Please select...', 'class' => 'form-control'])); ?>

								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label>Return Date</label> <input name="fromDate[]" class="form-control datepickerfield" type="text" placeholder="YYYY-MM-DD" value="<?php echo e($transit[3]['from_date']); ?>"/>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label>Return Date</label> <input name="uptoDate[]" class="form-control datepickerfield" type="text" placeholder="YYYY-MM-DD" value="<?php echo e($transit[3]['upto_date']); ?>"/>
								</div>
							</div>
						</div>
					</div><!-- addLocations -->
					<div class="row">
						<div class="col-md-12">
							<div class="form-group">
								<input type="submit" class="btn btn-primary" value="Submit"/> <input type="hidden" name="id" value="<?php echo e($trip->id); ?>"/>
								<?php echo e(csrf_field()); ?>

							</div>
						</div>
					</div>


			</form>
		</div>
	</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>