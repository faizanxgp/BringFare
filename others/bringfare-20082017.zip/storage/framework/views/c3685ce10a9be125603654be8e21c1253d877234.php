<header class="mb20">
	<div class="nav-container">


		<nav id="nav" class="navbar navbar-default navbar-fixed-top sb-slide">
			<div class="container">

				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#topnav" aria-expanded="false" aria-controls="topnav">
						<span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span>
					</button>
					<div id="logo" class="hidden-xsx">
						<a href="<?php echo e(route('home')); ?>"><img id="logo-img" src="<?php echo e(URL::to('src/images/logo.png')); ?>" alt=""/></a>
					</div>
				</div>


				<div id="topnav" class="hidden-xsx">
					<ul class="nav navbar-nav navbar-right">
						<li><?php if(isset($user)): ?> <?php echo e(isset($user->roles->first()->id) ? $user->roles->first()->id : 0); ?> <?php endif; ?></li>
						<li><a href="<?php echo e(route('search')); ?>">Browse Requests</a></li>
						<li><a id="postRequest" href="<?php echo e(route('create-request')); ?>">Post Request</a></li>
						<li><a id="browseTrip" href="<?php echo e(route('search-trips')); ?>">Browse Trip</a></li>
						<li><a id="postTrip" href="<?php echo e(route('create-trip')); ?>">Post Trip</a></li>

						<?php if(Auth::check()): ?>
							<li><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
							<li><a href="<?php echo e(route('inbox')); ?>">Inbox <sup><span class="label label-warning"><?php echo e(Auth::user()->hasMessage()); ?></span></sup></a></li>
							
							<li class="dropdown">
								<a class="dropdown-toggle" data-toggle="dropdown">Notifications <sup><span class="label label-warning"><?php echo e(Auth::user()->hasNotification()); ?></a>
								<ul class="dropdown-menu" role="menu">
									<?php $notifications = Auth::user()->getNotification(); ?>
									<?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<li><?php echo $n->description; ?></li>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<li><a href="<?php echo e(route('notification')); ?>" class="pull-right">View All</a></li>
								</ul>
							</li>
							<li><a href="<?php echo e(route('profile')); ?>">Profile</a></li>
							<li><a id="#">Contact</a></li>
							<li>
								<div class="btn-group" style="margin-left:10px">
									<button id="myid" type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
										<?php if(Auth::user()->image == ""): ?>
											<img class="img-circle" src="<?php echo e(URL::to('src/images/users/user1.jpg')); ?>" alt=""/>
										<?php else: ?>
											<img class="img-circle" src="<?php echo e(URL::to('/uploads/users/' . Auth::user()->image)); ?>" alt=""/>
										<?php endif; ?>
										&nbsp; <span class="menutext"><?php echo e(Auth::user()->name); ?></span>&nbsp; <span class="caret"></span>
									</button>
									<ul class="dropdown-menu dropdown-menu-right" role="menu">
										<li><a href="#">Bal: 0.00</a></li>

									

									<!--<li><a href="/xfers/wallet">Airfrov Wallet</a></li>-->
										<li><a href="<?php echo e(route('wallet')); ?>">Wallet</a></li>

										<!--<li><a href="/xfers/wallet">Airfrov Wallet</a></li>-->
										<li><a href="<?php echo e(route('settings')); ?>">Settings</a></li>
										<li><a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Logout</a>
											<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;"><?php echo e(csrf_field()); ?></form>
										</li>
									</ul>
								</div>
							</li>

						<?php else: ?>
							<li><a href="#">How it works</a></li>
							<li><a href="<?php echo e(route('login')); ?>">Login</a></li>
							<li><a href="<?php echo e(route('register')); ?>">Register</a></li>
							<li><a id="#">Contact</a></li>
						<?php endif; ?>


					</ul>
				</div>
			</div> <!-- end container div -->
		</nav>
	</div>
</header>