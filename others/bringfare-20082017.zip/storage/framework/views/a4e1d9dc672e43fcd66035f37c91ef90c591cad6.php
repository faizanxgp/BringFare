<?php $__env->startSection('title'); ?>
	Admin Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageHeading'); ?>
	User Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<section id="page-inner" class="header-margin">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<h2><i class="fa fa-envelope"></i> Trips </h2>
					<?php echo $__env->make('partials.sub-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				</div>
				<div class="col-md-12">
					<h3 class="inline"><i class="fa fa-list-ul"></i> Activities </h3>
					<div class="filterby">Filter by <select></select></div>

					<table class="table">
						<tr>
							<th>From Country</th>
							<th>From Date</th>
							<th>To Country</th>
							<th>Upto Date</th>
							<th>Type</th>
							<th>Return Date</th>
							<th>Notes</th>

							<th>Action</th>
						</tr>
						<?php $__currentLoopData = $trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


							<tr>
								<td><?php echo e($trip->country); ?></td>
								<td><?php echo e($trip->from_date); ?></td>
								<td><?php echo e($trip->country); ?></td>
								<td><?php echo e($trip->upto_date); ?></td>
								<td><?php echo e($trip->trip_type); ?></td>
								<td><?php echo e($trip->return_date); ?></td>

								<td><?php echo e($trip->notes); ?></td>


								<td><a class="btn btn-primary" href="<?php echo e(route('edit-trip', $trip->id)); ?>">Edit</a> <a class="btn btn-danger" href="">Delete</a></td>

							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</table>
					<p><a href="<?php echo e(route('create-trip')); ?>" class="btn btn-primary">Post Trip</a></p>
				</div>

			</div>
		</div>


	</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>