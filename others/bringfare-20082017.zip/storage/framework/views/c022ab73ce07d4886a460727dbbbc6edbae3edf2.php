<?php $__env->startSection('title'); ?>
	Admin Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageHeading'); ?>
	User Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<section id="page-inner" class="header-margin">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<h2><i class="fa fa-envelope"></i> Bids </h2>
					<?php echo $__env->make('partials.sub-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				</div>

				<div class="col-md-12">
					<h3 class="inline"><i class="fa fa-list-ul"></i> Activities </h3>
					<div class="filterby">Filter by <select></select></div>


					<table class="table">
						<tr>
							<th>Product</th>
<th>Status</th>
							<th>Bid Message</th>
							<th>Amount</th>
							<th>Bid Status</th>
							<th>User</th>
							<th>Date/Time</th>
							<th>Action</th>

						</tr>
						<?php $__currentLoopData = $bids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


							<tr>
								<td><a href="<?php echo e(route('request', $bid->product->id)); ?>"><?php echo e($bid->product->item_name); ?></a></td>
								<td><?php echo e(isset($bid->product->status) ? $bid->product->status : ''); ?></td>
								<td><?php echo e($bid->comments); ?></td>
								<td><?php echo e($bid->amount); ?> </td>
								<td><?php echo e($bid->status); ?></td>
								<td><a href="<?php echo e(route('profile', $bid->user->id)); ?>"><?php echo e($bid->user->name); ?></a></td>
<td><?php echo e($bid->created_at); ?></td>
								<td><a class="btn btn-primary ls-modal" href="<?php echo e(route('discuss', $bid->id)); ?>">Discuss</a> <?php if($bid->product->status=='Open'): ?> <a class="btn btn-danger" href="<?php echo e(route('request', $bid->id)); ?>">Select</a> <?php endif; ?></td>

							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</table>

				</div>

			</div>
		</div>


	</section>

	<div id="myModal" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					<h4 class="modal-title">BringFare</h4>
				</div>
				<div class="modal-body">
					<p>Loading...</p>
				</div>
				<div class="modal-footer">

				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
	<script>
		jQuery('.ls-modal').on('click', function(e){
			e.preventDefault();
			jQuery('#myModal').modal('show').find('.modal-body').load(jQuery(this).attr('href'));
		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>