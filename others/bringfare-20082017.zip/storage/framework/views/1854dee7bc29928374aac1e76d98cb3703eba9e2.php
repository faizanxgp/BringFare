<?php $__env->startSection('title'); ?>
	Admin Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageHeading'); ?>
	User Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<section id="page" class="header-margin">
		<div class="container">
			<div class="row request-title">
				<div class="col-md-12">
					<?php if(Session::has('flash_message')): ?>
						<div class="alert alert-success">
							<?php echo e(Session::get('flash_message')); ?>

						</div>
					<?php endif; ?>

				</div>
			</div>
			<div class="row request-section">
				<div class="col-md-12 ">
					<div class="row request-details">
						<div class="col-md-6">
							<h1><?php echo e($user->name); ?> </h1>



							<div class="details">


								<div class="user-details">
									<b>Requested by </b><br/><br/>
									<div class="user-img inline"><img class="img-circle user-img1" src="<?php echo e(URL::to('src/images/users/user1.jpg')); ?>" alt=""/></div>
									<div class="title-img inline"><a href=""><?php echo e($user->name); ?> </a><br/>Start <br/>(8 reviews)</div>
								</div>

							</div>

							<h2>Reviews </h2>


						</div>

						<div class="col-md-6">
							<div class="comments ">
								<h3>Projects</h3>
								<div class="separator"></div>
								<?php if( !$products->isEmpty() ): ?>
									<table class="table messages">
										<tr>
											<th>Product</th>
											<th>User</th>
											<th>Date</th>
											<th>Action</th>
										</tr>
										<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<tr>
												<td><a class="" href="<?php echo e(route('admin.product', $product->id)); ?>"><?php echo e($product->item_name); ?></a></td>
												<td><a href="#"><?php echo e($product->user->name); ?></a></td>
												<td><?php echo e($product->created_at); ?></td>
												<td><a href="" class="btn btn-primary">Edit</a></td>
											</tr>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

									</table>
								<?php else: ?>

									<p>No comments yet</p>
								<?php endif; ?>
							</div>

							<div class="comments ">
								<h3>Bids</h3>
								<div class="separator"></div>
								<?php if( !$bids->isEmpty() ): ?>
									<table class="table messages">
										<tr>
											<th>Product</th>
											<th>User</th>
											<th>Date</th>
											<th>Action</th>
										</tr>
										<?php $__currentLoopData = $bids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<tr>
												<td><a class="" href="<?php echo e(route('admin.product', $bid->id)); ?>"><?php echo e($bid->comments); ?></a></td>
												<td><a href="#"><?php echo e($bid->status); ?></a></td>
												<td><?php echo e($product->created_at); ?></td>
												<td><a href="" class="btn btn-primary">Edit</a></td>
											</tr>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

									</table>
								<?php else: ?>

									<p>No comments yet</p>
								<?php endif; ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<div id="myModal" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					<h4 class="modal-title">BringFare</h4>
				</div>
				<div class="modal-body">
					<p>Loading...</p>
				</div>
				<div class="modal-footer">

				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
	<script>
		jQuery('.ls-modal').on('click', function (e) {
			e.preventDefault();
			jQuery('#myModal').modal('show').find('.modal-body').load(jQuery(this).attr('href'));
		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>