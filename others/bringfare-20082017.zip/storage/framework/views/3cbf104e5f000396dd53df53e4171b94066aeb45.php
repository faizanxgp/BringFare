<?php $__env->startSection('title'); ?>
	Admin Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageHeading'); ?>
	User Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<section id="modal" class="header-margin-zero">

		<div class="">
			<div class="">
				<div class="" style="max-height: 400px; overflow: scroll;">
					<?php if(Session::has('flash_message')): ?>
						<div class="alert alert-success">
							<?php echo e(Session::get('flash_message')); ?>

						</div>
					<?php endif; ?>
					<h2><i class="fa fa-gift"></i> Discuss Details </h2>
					<h3>Project: <?php echo e($product->item_name); ?> by <a href=""><?php echo e($product->user->name); ?></a> <br/> Status: <?php echo e($product->status); ?></h3>
					<h4>Bid: <?php echo e($bid->comments); ?> for <?php echo e($bid->amount); ?> by <a href=""><?php echo e($bid->user->name); ?></a> - Status: <?php echo e($bid->status); ?></h4>
					<p><a href="#">Guidelines for communication</a></p>


					<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="discuss-message <?php if($comment->comment_by=='Buyer'): ?> align-right discuss-buyer <?php else: ?> discuss-seller <?php endif; ?>"><a href=""><?php echo e(isset($comment->user->name) ? $comment->user->name : 'NotFound'); ?></a>
							<i><?php echo e($comment->created_at); ?></i><br/><br/><?php echo e($comment->comments); ?> <?php if($comment->attachement): ?><br/><a class="" href="<?php echo e(URL::to('/uploads/comments/' . $comment->attachement)); ?>" target="_blank"><img
										src="<?php echo e(URL::to('/uploads/comments/' . $comment->attachement)); ?>" class="thumbnail"/></a><?php endif; ?> </div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<form method="post" action="<?php echo e(route('add-discuss')); ?>" enctype="multipart/form-data">
						<div class="form-group">
							<label>Add Comment</label> <textarea class="form-control" name="comment" required></textarea>
						</div>
						<div class="form-group"><label>Attachement (optional)</label><input type="file" class="form-control" name="attachement"/></div>
						<input type="hidden" name="bid_id" value="<?php echo e($bid->id); ?>"/>

						<input class="btn btn-primary" type="submit" value="Add Comment"/>
						<p>&nbsp;</p>
						<?php echo e(csrf_field()); ?>


					</form>
					<div class="actions">
						<div class="form-group">
						<?php if($user_id == $product->user->id): ?>
							<!-- buyer -->
								<form method="post" action="<?php echo e(route('bid-status')); ?>">
									<input type="hidden" name="bid_id" value="<?php echo e($bid->id); ?>"/> <label>Change Status to: </label>
									<?php if($product->status == 'Awarded'): ?>
										<input type="hidden" name="status" value="Pending Purchase"/>
										<input id="btn-funded" class="btn btn-danger" type="submit" value="Add Funds"/>
									<?php endif; ?>
									<?php if($product->status == 'Pending Acknowledgment'): ?>
										<input type="hidden" name="status" value="Completed"/>
										<input id="btn-acknowledge" class="btn btn-danger" type="submit" value="Received"/>
									<?php endif; ?>
									<?php if($product->status == 'Completed'): ?>
										<input type="hidden" name="status" value="Rate"/>
										<input id="btn-rate" class="btn btn-danger" type="submit" value="Rate your Experience"/>
									<?php endif; ?>
									<?php echo e(csrf_field()); ?>

								</form>

						<?php endif; ?>
						<?php if($user_id == $bid->user->id): ?>
							<!-- seller -->
								<form method="post" action="<?php echo e(route('bid-status')); ?>">
									<input type="hidden" name="bid_id" value="<?php echo e($bid->id); ?>"/> <label>Change Status to: </label>
									<?php if($product->status == 'Pending Purchase'): ?>
										<input type="hidden" name="status" value="Pending Delivery"/>
										<input id="btn-purchased" class="btn btn-danger" type="submit" value="Product Purchased"/>
									<?php endif; ?>
									<?php if($product->status == 'Pending Delivery'): ?>
										<input type="hidden" name="status" value="Pending Acknowledgment"/>
										<input id="btn-delivered" class="btn btn-danger" type="submit" value="Delivered"/>
									<?php endif; ?>
									<?php if($product->status == 'Completed'): ?>
										<input type="hidden" name="status" value="Rate"/>
										<input id="btn-rate-2" class="btn btn-danger" type="submit" value="Rate your Experience"/>
									<?php endif; ?>
									<?php echo e(csrf_field()); ?>

								</form>
							<?php endif; ?>

						</div>
					</div>
				</div>
			</div>
	</section>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>

	<script>
		$(document).ready(function () {

			// button add funds
			$('#btn-funded').on('click', function (e) {
				e.preventDefault();

				var form = $(this).parents('form');
				swal({
					title: "Are you sure?",
					text: "This will Add Funds in Escrow",
					type: "warning",
					showCancelButton: true,
					confirmButtonColor: "#DD6B55",
					confirmButtonText: "Yes, Continue!",
					closeOnConfirm: false
				}).then(
						function (isConfirm) {
							console.log('confirmed');
							if (isConfirm) form.submit();
						},
						function () {
							console.log('cancel');
						}
				);

			});

			// button acknowledge
			$('#btn-acknowledge').on('click', function (e) {
				e.preventDefault();

				var form = $(this).parents('form');
				swal({
					title: "Are you sure?",
					text: "This will confirm you have received product.",
					type: "warning",
					showCancelButton: true,
					confirmButtonColor: "#DD6B55",
					confirmButtonText: "Yes, Continue!",
					closeOnConfirm: false
				}).then(
						function (isConfirm) {
							console.log('confirmed');
							if (isConfirm) form.submit();
						},
						function () {
							console.log('cancel');
						}
				);

			});

			// button acknowledge
			$('#btn-rate').on('click', function (e) {
				e.preventDefault();

				var form = $(this).parents('form');
				swal({
					title: "Are you sure?",
					text: "This will add your rating for provider.",
					type: "warning",
					showCancelButton: true,
					confirmButtonColor: "#DD6B55",
					confirmButtonText: "Yes, Continue!",
					closeOnConfirm: false
				}).then(
						function (isConfirm) {
							console.log('confirmed');
							if (isConfirm) form.submit();
						},
						function () {
							console.log('cancel');
						}
				);

			});

			// button acknowledge
			$('#btn-purchased').on('click', function (e) {
				e.preventDefault();

				var form = $(this).parents('form');
				swal({
					title: "Are you sure?",
					text: "This will confirm that product has been purchased.",
					type: "warning",
					showCancelButton: true,
					confirmButtonColor: "#DD6B55",
					confirmButtonText: "Yes, Continue!",
					closeOnConfirm: false
				}).then(
						function (isConfirm) {
							console.log('confirmed');
							if (isConfirm) form.submit();
						},
						function () {
							console.log('cancel');
						}
				);

			});

			// button acknowledge
			$('#btn-purchased').on('click', function (e) {
				e.preventDefault();

				var form = $(this).parents('form');
				swal({
					title: "Are you sure?",
					text: "This will confirm that product has been purchased.",
					type: "warning",
					showCancelButton: true,
					confirmButtonColor: "#DD6B55",
					confirmButtonText: "Yes, Continue!",
					closeOnConfirm: false
				}).then(
						function (isConfirm) {
							console.log('confirmed');
							if (isConfirm) form.submit();
						},
						function () {
							console.log('cancel');
						}
				);

			});

			// button acknowledge
			$('#btn-delivered').on('click', function (e) {
				e.preventDefault();

				var form = $(this).parents('form');
				swal({
					title: "Are you sure?",
					text: "This will confirm that product has been delivered.",
					type: "warning",
					showCancelButton: true,
					confirmButtonColor: "#DD6B55",
					confirmButtonText: "Yes, Continue!",
					closeOnConfirm: false
				}).then(
						function (isConfirm) {
							console.log('confirmed');
							if (isConfirm) form.submit();
						},
						function () {
							console.log('cancel');
						}
				);

			});

			// button acknowledge
			$('#btn-rate-2').on('click', function (e) {
				e.preventDefault();

				var form = $(this).parents('form');
				swal({
					title: "Are you sure?",
					text: "This will add your rating for buyer.",
					type: "warning",
					showCancelButton: true,
					confirmButtonColor: "#DD6B55",
					confirmButtonText: "Yes, Continue!",
					closeOnConfirm: false
				}).then(
						function (isConfirm) {
							console.log('confirmed');
							if (isConfirm) form.submit();
						},
						function () {
							console.log('cancel');
						}
				);

			});


		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>