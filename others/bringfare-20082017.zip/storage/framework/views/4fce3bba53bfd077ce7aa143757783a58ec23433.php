<?php $__env->startSection('title'); ?>
	Admin Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageHeading'); ?>
	User Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<section id="page-inner" class="header-margin">
		<div class="container">
			<h2><i class="fa fa-envelope"></i> Profile </h2>
			<p>&nbsp;</p>
			<div class="row">
				<div class="col-md-9 block">
					<div class="row">
						<div class="col-md-4">
							<?php if($member->image == ""): ?>
								<img class="user-img3" src="<?php echo e(URL::to('src/images/users/user1.jpg')); ?>" alt=""/>
							<?php else: ?>
								<img class="user-img3" src="<?php echo e(URL::to('/uploads/users/' . $member->image)); ?>" alt=""/>
							<?php endif; ?>
							<div>(8 reviews) <br/> Member since <?php echo e($member->created_at); ?></div>
						</div>
						<div class="col-md-8">
							<h2><?php echo e($member->name); ?></h2>
							<h3>About me</h3>
							<p><?php echo e($member->about); ?></p>
						</div>
					</div>
				</div>

				<div class="col-md-3">
					<div class="block">
						<p>
							<?php if($member->id == $user_id): ?>
								<a href="<?php echo e(route('edit-profile')); ?>" class="btn btn-primary form-control">Update</a>
							<?php else: ?>
								<?php if($member->hasFollowing($user_id)): ?>
									<a href="<?php echo e(route('unfollow', $member->id)); ?>" class="btn btn-primary form-control">Un Follow</a>
								<?php else: ?>
									<a href="<?php echo e(route('follow', $member->id)); ?>" class="btn btn-primary form-control">Follow</a>
								<?php endif; ?>
							<?php endif; ?>
						</p>


						<h3>Activity</h3>
						<div class="activity">
							<div class="icon"><i class="fa fa-gift"></i></div>
							Requests: <?php echo e($member->product->count()); ?>

						</div>
						<div class="activity">
							<div class="icon"><i class="fa fa-plane"></i></div>
							Trips: <?php echo e($member->trip->count()); ?>

						</div>
						<div class="activity">
							<div class="icon"><i class="fa fa-user"></i></div>
							Followed by: <?php echo e($member->following->count()); ?>

						</div>
						<div class="activity">
							<div class="icon"><i class="fa fa-user"></i></div>
							Following: <?php echo e($member->followBy->count()); ?>

						</div>

					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<h3 class="inline"><i class="fa fa-list-ul"></i> Projects </h3>

					<h4>Projects posted: <?php echo e($request_count); ?></h4>
					<h4>Reviews: <?php echo e($member->reviews_buyer()); ?></h4>
					<h4>Avg. Rating: <div class="rateit" data-rateit-value="<?php echo e($member->rating_buyer()); ?>" data-rateit-ispreset="true" data-rateit-readonly="true"></div></h4>
					<?php $__currentLoopData = $review_buyer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="review-box block" style="border: 1px solid #bbbbbb; padding: 10px; margin-bottom: 10px; ">
							<p>Rating by <a href="<?php echo e(route('profile', $review->rating_by)); ?>"><?php echo e($review->ratingby->name); ?></a> for <a href="<?php echo e(route('request', $review->product_id)); ?>"><?php echo e($review->product->item_name); ?></a></p>
							<p>Rated <div class="rateit" data-rateit-value="<?php echo e($review->rating); ?>" data-rateit-ispreset="true" data-rateit-readonly="true"></div></p>
							<p>
							<blockquote><?php echo e($review->review); ?></blockquote>
							</p>
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				</div>
				<div class="col-md-6">
					<h3 class="inline"><i class="fa fa-comments-o"></i> Bids </h3>

					<h4>Products purchased: <?php echo e($bid_count); ?></h4>
					<h4>Reviews: <?php echo e($member->reviews_seller()); ?></h4>
					<h4>Avg. Rating: <div class="rateit" data-rateit-value="<?php echo e($member->rating_seller()); ?>" data-rateit-ispreset="true" data-rateit-readonly="true"></div></h4>
					<?php $__currentLoopData = $review_seller; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="review-box block" style="border: 1px solid #bbbbbb; padding: 10px; margin-bottom: 10px; ">
							<p>Rating by <a href="<?php echo e(route('profile', $review->rating_by)); ?>"><?php echo e($review->ratingby->name); ?></a> for <a href="<?php echo e(route('request', $review->product_id)); ?>"><?php echo e($review->product->item_name); ?></a></p>
							<p>Rated <div class="rateit" data-rateit-value="<?php echo e($review->rating); ?>" data-rateit-ispreset="true" data-rateit-readonly="true"></div></p>
							<p>
							<blockquote><?php echo e($review->review); ?></blockquote>
							</p>
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				</div>
			</div>
		</div>


	</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>