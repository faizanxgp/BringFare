<?php $__env->startSection('title'); ?>
	Admin Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageHeading'); ?>
	User Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<section id="page-inner" class="header-margin">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<h2><i class="fa fa-envelope"></i> Wallet </h2>
				</div>
				<div class="col-md-6">
					<h3 class="inline"><i class="fa fa-list-ul"></i> Transactions </h3>
					<div class="filterby">Filter by <select></select></div>
					<ul class="activities">
						<li>You dont have any activity yet.</li>
					</ul>

				</div>
				<div class="col-md-6">
					<h3 class="inline"><i class="fa fa-comments-o"></i> Add Funds </h3>
					<div class="filterby">Filter by <select></select></div>
					<form>
						<div class="form-group">
							<div class="">
								<label>Online Payment Method</label><br />
								<label><input type="radio" name="method" value="paypal" checked> PayPal </label> <label><input type="radio" name="method" value="cc"> Credit Card (Visa/Master) </label>
							</div>


						</div>

						<div class="form-group ">
							<div class="">
								<label>Amount (USD)</label> <input name="price" type="text" class="form-control" value="0"/>

							</div>
						</div>

						<div class="form-group">
							<div class="">

								<input class="btn btn-primary" type="submit" value="submit"/>
								<?php echo e(csrf_field()); ?>

							</div>
						</div>

						<div class="form-group">
							<br />
							<label>Other Payment Method</label><br />
							<strong>Bank Ltd</strong><br />
							Account Title: BringFare <br />
							Account #: 0000-000000000000-0

							<br /><br />

							<strong>EasyPaisa</strong><br />
							Account Title: BringFare <br />
							Account #: 0340-1234567

							<br /><br />

							<strong>Please contact our support after payment. </strong>

						</div>




					</form>
				</div>
			</div>
		</div>


	</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>