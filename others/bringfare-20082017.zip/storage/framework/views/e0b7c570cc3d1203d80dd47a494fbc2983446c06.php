<ul class="inline-menu">
    <li><a href="<?php echo e(route('requests')); ?>">Requests</a></li>
    <li><a href="<?php echo e(route('trips')); ?>">Trips</a></li>
    <li><a href="<?php echo e(route('bids')); ?>">Bids Received</a></li>
    <li><a href="<?php echo e(route('applied')); ?>">My Bids</a></li>
</ul>