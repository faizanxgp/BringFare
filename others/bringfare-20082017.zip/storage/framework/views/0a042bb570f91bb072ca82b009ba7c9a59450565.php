<?php $__env->startSection('title'); ?>
	Admin Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageHeading'); ?>
	User Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<section id="modal" class="header-margin-zero">

		<div class="">
			<div class="">
				<div class="" style="max-height: 400px; overflow: scroll;">
					<?php if(Session::has('flash_message')): ?>
						<div class="alert alert-success">
							<?php echo e(Session::get('flash_message')); ?>

						</div>
					<?php endif; ?>
					<h2><i class="fa fa-gift"></i> Invite Users </h2>
					<h3>Project: <?php echo e($product->item_name); ?> by <a href=""><?php echo e($product->user->name); ?></a> <br/> Status: <?php echo e($product->status); ?></h3>



					<form method="post" action="<?php echo e(route('post-invite-request')); ?>">
						<div class="form-group">
							<input type="checkbox" name="check1" value="1" /> <label>People visiting <?php echo e($product->country); ?> ( <?php echo e($trips->count()); ?> persons )</label>  <br />
							
							<input type="checkbox" name="check3" value="1" /> <label>People who follow me ( <?php echo e($following2->count()); ?> persons )</label>  <br />
							<input type="checkbox" name="check4" value="1" /> <label>Emails </label>  <br />
							<textarea class="form-control" name="emails" cols="80" rows="5"></textarea>
						</div>
						<input type="hidden" name="product_id" value="<?php echo e($product->id); ?>"/>
						<input class="btn btn-primary" type="submit" value="Invite People "/>
						<p>&nbsp;</p>
						<?php echo e(csrf_field()); ?>


					</form>

				</div>
			</div>
	</section>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>

	<script>
		$(document).ready(function() {

			// button add funds
			$('#btn-funded').on('click',function(e){
				e.preventDefault();

				var form = $(this).parents('form');
				swal({
					title: "Are you sure?",
					text: "This will Add Funds in Escrow",
					type: "warning",
					showCancelButton: true,
					confirmButtonColor: "#DD6B55",
					confirmButtonText: "Yes, Continue!",
					closeOnConfirm: false
				}).then(
					function(isConfirm) {
						console.log('confirmed');
						if (isConfirm) form.submit();
					},
					function () {
						console.log('cancel');
					}
				);

			});

			// button acknowledge
			$('#btn-acknowledge').on('click',function(e){
				e.preventDefault();

				var form = $(this).parents('form');
				swal({
					title: "Are you sure?",
					text: "This will confirm you have received product.",
					type: "warning",
					showCancelButton: true,
					confirmButtonColor: "#DD6B55",
					confirmButtonText: "Yes, Continue!",
					closeOnConfirm: false
				}).then(
						function(isConfirm) {
							console.log('confirmed');
							if (isConfirm) form.submit();
						},
						function () {
							console.log('cancel');
						}
				);

			});

			// button acknowledge
			$('#btn-rate').on('click',function(e){
				e.preventDefault();

				var form = $(this).parents('form');
				swal({
					title: "Are you sure?",
					text: "This will add your rating for provider.",
					type: "warning",
					showCancelButton: true,
					confirmButtonColor: "#DD6B55",
					confirmButtonText: "Yes, Continue!",
					closeOnConfirm: false
				}).then(
						function(isConfirm) {
							console.log('confirmed');
							if (isConfirm) form.submit();
						},
						function () {
							console.log('cancel');
						}
				);

			});

			// button acknowledge
			$('#btn-purchased').on('click',function(e){
				e.preventDefault();

				var form = $(this).parents('form');
				swal({
					title: "Are you sure?",
					text: "This will confirm that product has been purchased.",
					type: "warning",
					showCancelButton: true,
					confirmButtonColor: "#DD6B55",
					confirmButtonText: "Yes, Continue!",
					closeOnConfirm: false
				}).then(
						function(isConfirm) {
							console.log('confirmed');
							if (isConfirm) form.submit();
						},
						function () {
							console.log('cancel');
						}
				);

			});

			// button acknowledge
			$('#btn-purchased').on('click',function(e){
				e.preventDefault();

				var form = $(this).parents('form');
				swal({
					title: "Are you sure?",
					text: "This will confirm that product has been purchased.",
					type: "warning",
					showCancelButton: true,
					confirmButtonColor: "#DD6B55",
					confirmButtonText: "Yes, Continue!",
					closeOnConfirm: false
				}).then(
						function(isConfirm) {
							console.log('confirmed');
							if (isConfirm) form.submit();
						},
						function () {
							console.log('cancel');
						}
				);

			});

			// button acknowledge
			$('#btn-delivered').on('click',function(e){
				e.preventDefault();

				var form = $(this).parents('form');
				swal({
					title: "Are you sure?",
					text: "This will confirm that product has been delivered.",
					type: "warning",
					showCancelButton: true,
					confirmButtonColor: "#DD6B55",
					confirmButtonText: "Yes, Continue!",
					closeOnConfirm: false
				}).then(
						function(isConfirm) {
							console.log('confirmed');
							if (isConfirm) form.submit();
						},
						function () {
							console.log('cancel');
						}
				);

			});

			// button acknowledge
			$('#btn-rate-2').on('click',function(e){
				e.preventDefault();

				var form = $(this).parents('form');
				swal({
					title: "Are you sure?",
					text: "This will add your rating for buyer.",
					type: "warning",
					showCancelButton: true,
					confirmButtonColor: "#DD6B55",
					confirmButtonText: "Yes, Continue!",
					closeOnConfirm: false
				}).then(
						function(isConfirm) {
							console.log('confirmed');
							if (isConfirm) form.submit();
						},
						function () {
							console.log('cancel');
						}
				);

			});


		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>