<?php echo $__env->yieldContent('content'); ?>

<?php echo $__env->yieldContent('js'); ?>