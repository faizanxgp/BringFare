@extends('layouts.main')

@section('title')
	Admin Dashboard
@endsection

@section('pageHeading')
	User Dashboard
@endsection

@section('content')
	<section id="page" class="header-margin">
		<div class="container">

			<div class="row">
				<div class="col-md-3 sidebar">
					{{--<div class="header">Refine Search</div>--}}
{{--<p>&nbsp;</p>--}}
					<form method="post" action="{{ route('post-search-trips') }}">

						<label> From Country: </label>

						<div class="form-group">
							{{ Form::select('f_country', $countries, null, ['class' => 'form-control', 'placeholder' => 'Please select...', '']) }}
						</div>

						<label> To Country <span class="required">*</span> : </label>

						<div class="form-group">
							{{ Form::select('t_country', $countries, null, ['class' => 'form-control', 'placeholder' => 'Please select...', 'required']) }}
						</div>

						<label> From Date: </label>

						<div class="form-group ">
							<input type="text" id="datepicker1" name="from_date" class="form-control" placeholder="YYYY-MM-DD"/>
						</div>

						<label> To Date: </label>

						<div class="form-group ">
							<input type="text" id="datepicker2" name="upto_date" class="form-control" placeholder="YYYY-MM-DD"/>
						</div>

						<div class="form-group ">
							<input type="submit" class="btn btn-primary"/>
							{{ csrf_field() }}
						</div>

					</form>


				</div><!-- .sidebar -->
				<div class="col-md-9">

					<div class="search-results">
						<div class="row">
							@foreach($trips as $trip)
								<div class="col-md-4">
									<div class="item-card card">
										<div class="card-top">

											<div class="item-title">{{ $trip->country }} - {{ $trip->country_to }}</div>
											<div class="item-status"><label class="label label-primary">{{ $trip->from_date }} to {{ $trip->upto_date }}</label></div>

										</div>
										<div class="card-footer">
											<div class="user-img inline"><img src="{{ URL::to('src/images/users/user1.jpg') }}" alt=""/></div>
											<div class="title-img inline"><a href="">{{ $trip->user->name }}</a></div>
										</div>
									</div>
								</div>
							@endforeach

							<div class="col-md-4">
								<div class="item-card card">
									<div class="card-top">
										<div class="image"><a href="#"><img src="{{ URL::to('src/images/items/item1.jpg') }}" alt=""/></a></div>
										<div class="item-title">item name</div>
										<div class="item-status"><label class="label label-primary">Open</label></div>
									</div>
									<div class="card-footer">
										<div class="user-img inline"><img src="{{ URL::to('src/images/users/user1.jpg') }}" alt=""/></div>
										<div class="title-img inline">Buy in JAPAN<br/>Willing to pay SGD 1000</div>
									</div>
								</div>
							</div>
						</div>
					</div><!-- .search-results -->

				</div>
			</div>

		</div>


	</section>


@endsection