<ul class="inline-menu">
    <li><a href="{{ route('requests') }}">Requests</a></li>
    <li><a href="{{ route('trips') }}">Trips</a></li>
    <li><a href="{{ route('bids') }}">Bids Received</a></li>
    <li><a href="{{ route('applied') }}">My Bids</a></li>
</ul>