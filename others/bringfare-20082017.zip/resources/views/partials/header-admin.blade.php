<header class="mb20">
	<div class="nav-container">


		<nav id="nav" class="navbar navbar-default navbar-fixed-top sb-slide">
			<div class="container">

				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#topnav" aria-expanded="false" aria-controls="topnav">
						<span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span>
					</button>
					<div id="logo" class="hidden-xsx">
						<a href="/"><img id="logo-img" src="{{ URL::to('src/images/logo.png') }}" alt=""/></a>
					</div>
				</div>


				<div id="topnav" class="hidden-xsx">
					<ul class="nav navbar-nav navbar-right">
						<li></li>
						<li><a href="{{ route('home') }}">Home</a></li>


						@if(Auth::check())
							<li><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
							<li><a href="{{ route('admin.products') }}">Projects</a></li>
							<li><a href="{{ route('admin.users') }}">Users</a></li>
							<li><a href="{{ route('admin.categories') }}">Categories</a></li>

							<li>
								<div class="btn-group" style="margin-left:10px">
									<button id="myid" type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
										<img src="https://d8hh9kinq36uh.cloudfront.net/profile/default-profile-pic.jpg" class="img-circle" alt=""/>&nbsp;<span class="menutext">{{ Auth::user()->name }}</span>&nbsp; <span class="caret"></span>
									</button>
									<ul class="dropdown-menu dropdown-menu-right" role="menu">
										{{--<li><a href="{{ route('profile') }}">Profile</a></li>--}}
										{{--<li><a href="{{ route('settings') }}">Credit</a></li>--}}

										{{--<!--<li><a href="/xfers/wallet">Airfrov Wallet</a></li>-->--}}
										{{--<li><a href="{{ route('wallet') }}">Wallet</a></li>--}}

										{{--<!--<li><a href="/xfers/wallet">Airfrov Wallet</a></li>-->--}}
										{{--<li><a href="{{ route('settings') }}">Settings</a></li>--}}
										<li><a href="{{ route('admin.logout') }}">Logout</a></li>
									</ul>
								</div>
							</li>

						@else
							<li><a href="#">How it works</a></li>
							<li><a href="{{ route('login') }}">Login</a></li>
							<li><a href="{{ route('register') }}">Register</a></li>
						@endif

					</ul>
				</div>
			</div> <!-- end container div -->
		</nav>
	</div>
</header>