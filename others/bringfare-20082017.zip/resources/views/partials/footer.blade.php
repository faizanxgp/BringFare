<footer>
	<div class="row1">
		<div class="container">
			<div class="row">
				<div class="col-md-12 text-center">
					<h3>HAVE ANY QUESTIONS? +92 300 111-1111</h3>
				</div>
			</div>
		</div>
	</div>
	<div class="row2">
		<div class="container">
			<div class="row">
				<div class="col-md-2">

					<ul>
						<li><a class="block textCenter" href="#">About us</a></li>
						<li><a class="block textCenter" href="#">Browse</a></li>
						<li><a class="block textCenter" href="#">Post Request</a></li>
						<li><a class="block textCenter" href="#">Post Trip</a></li>
						<li><a class="block textCenter" href="#">How it works?</a></li>

					</ul>
				</div>
				<div class="col-md-2">

					<ul>
						<li><a class="block textCenter" href="#">FAQ</a></li>
						<li><a class="block textCenter" href="#">Blog</a></li>
						<li><a class="block textCenter" href="#">Mobile Analytics</a></li>
						<li><a class="block textCenter" href="#">Terms and Conditions</a></li>
						<li><a class="block textCenter" href="#">Privacy Policy</a></li>

					</ul>
				</div>
				<div class="col-md-4">

					<ul class="no-bullets">
						<li><i class="fa fa-map-marker"></i> Address</li>
						<li><i class="fa fa-phone"></i> +92 300 123-4567</li>
						<li><i class="fa fa-envelope-o"></i> info@bringfare.com</li>


					</ul>
				</div>
				<div class="col-md-4">
					<h4 class="bold"> Stay Updated </h4>
					<p>Never miss any update by BringFare</p>
					<form>
						<div class="form-group"><input type="text" class="form-control" placeholder="Your email address"/></div>
						<p>We hate spam like you. <input type="button" class="btn btn-primary pull-right" value="COUNT ME IN"/></p>
					</form>

				</div>
			</div>
			<div class="row3">
				<div class="row">
					<div class="col-md-6">Follow us : <i class="fa fa-facebook"></i> <i class="fa fa-twitter"></i> <i class="fa fa-linkedin"></i></div>
					<div class="col-md-6 ">
						<div class="pull-right"> &copy; All rights reserved</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</footer>