@extends('layouts.admin')

@section('title')
	Admin Dashboard
@endsection

@section('pageHeading')
	User Dashboard
@endsection

@section('content')
	<section id="page" class="header-margin">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<h2><i class="fa fa-envelope"></i> Users </h2>
				</div>

				<div class="col-md-12">
					<h3 class="inline"><i class="fa fa-comments-o"></i> Messages </h3>
					<div class="filterby">Filter by <select></select></div>
					<table class="table messages">
						<tr>
							<th>Name</th>
							<th>Email</th>
							<th>Date</th>
							<th>Action</th>
						</tr>
						@foreach($users as $user)
							<tr>
								<td><a class="" href="{{ route('admin.user', $user->id) }}">{{ $user->name }}</a></td>
								<td><a href="#">{{ $user->email }}</a></td>
								<td>{{ $user->created_at }}</td>
								<td><a href="" class="btn btn-primary">Edit</a></td>
							</tr>
						@endforeach
						<tr>
							<td colspan="4">{{ $users->links() }}</td>
						</tr>
					</table>
				</div>
			</div>
		</div>


	</section>

@endsection
