@extends('layouts.admin')

@section('title')
	Admin Dashboard
@endsection

@section('pageHeading')
	User Dashboard
@endsection

@section('content')
	<section id="page" class="header-margin">
		<div class="container">
			<div class="row request-title">
				<div class="col-md-12">
					@if(Session::has('flash_message'))
						<div class="alert alert-success">
							{{ Session::get('flash_message') }}
						</div>
					@endif

				</div>
			</div>
			<div class="row request-section">
				<div class="col-md-12 ">
					<div class="row request-details">
						<div class="col-md-6">
							<h1>{{ $user->name }} </h1>
							<div class="details">
								<div class="user-details">
									<b>Requested by </b><br/><br/>
									<div class="user-img inline">
										@if($user->image == "")
											<img class="img-circle user-img1" src="{{ URL::to('src/images/users/user1.jpg') }}" alt=""/>
										@else
											<img class="img-circle user-img1" src="{{ URL::to('/uploads/users/' . $user->image) }}" alt=""/>
										@endif
									</div>
									<div class="title-img inline"><a href="">{{ $user->name }} </a><br/>Start <br/>(8 reviews)</div>
								</div>

							</div>

							<h2>Reviews </h2>


						</div>

						<div class="col-md-6">
							<div class="comments ">
								<h3>Projects</h3>
								<div class="separator"></div>
								@if( !$products->isEmpty() )
									<table class="table messages">
										<tr>
											<th>Product</th>
											<th>User</th>
											<th>Date</th>
											<th>Action</th>
										</tr>
										@foreach($products as $product)
											<tr>
												<td><a class="" href="{{ route('admin.product', $product->id) }}">{{ $product->item_name }}</a></td>
												<td><a href="#">{{ $product->user->name }}</a></td>
												<td>{{ $product->created_at }}</td>
												<td><a href="" class="btn btn-primary">Edit</a></td>
											</tr>
										@endforeach

									</table>
								@else

									<p>No comments yet</p>
								@endif
							</div>

							<div class="comments ">
								<h3>Bids</h3>
								<div class="separator"></div>
								@if( !$bids->isEmpty() )
									<table class="table messages">
										<tr>
											<th>Product</th>
											<th>User</th>
											<th>Date</th>
											<th>Action</th>
										</tr>
										@foreach($bids as $bid)
											<tr>
												<td><a class="" href="{{ route('admin.product', $bid->id) }}">{{ $bid->comments }}</a></td>
												<td><a href="#">{{ $bid->status }}</a></td>
												<td>{{ $product->created_at }}</td>
												<td><a href="" class="btn btn-primary">Edit</a></td>
											</tr>
										@endforeach

									</table>
								@else

									<p>No comments yet</p>
								@endif
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<div id="myModal" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					<h4 class="modal-title">BringFare</h4>
				</div>
				<div class="modal-body">
					<p>Loading...</p>
				</div>
				<div class="modal-footer">

				</div>
			</div>
		</div>
	</div>
@endsection

@section('js')
	<script>
		jQuery('.ls-modal').on('click', function (e) {
			e.preventDefault();
			jQuery('#myModal').modal('show').find('.modal-body').load(jQuery(this).attr('href'));
		});
	</script>
@endsection