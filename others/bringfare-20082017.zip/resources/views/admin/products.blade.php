@extends('layouts.admin')

@section('title')
	Admin Dashboard
@endsection

@section('pageHeading')
	User Dashboard
@endsection

@section('content')
	<section id="page" class="header-margin">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<h2><i class="fa fa-envelope"></i> Products </h2>
				</div>

				<div class="col-md-12">
					<h3 class="inline"><i class="fa fa-comments-o"></i> Messages </h3>
					<div class="filterby">Filter by <select></select></div>
					<table class="table messages">
						<tr>
							<th>Product</th>
							<th>User</th>
							<th>Date</th>
							<th>Action</th>
						</tr>
						@foreach($products as $product)
							<tr>
								<td><a class="" href="{{ route('admin.product', $product->id) }}">{{ $product->item_name }}</a></td>
								<td><a href="#">{{ $product->user->name }}</a></td>
								<td>{{ $product->created_at }}</td>
								<td><a href="" class="btn btn-primary">Edit</a></td>
							</tr>
						@endforeach
						<tr>
							<td colspan="4">{{ $products->links() }}</td>
						</tr>
					</table>
				</div>
			</div>
		</div>
	</section>

@endsection