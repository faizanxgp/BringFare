@extends('layouts.main')

@section('title')
	Admin Dashboard
@endsection

@section('pageHeading')
	User Dashboard
@endsection

@section('content')
	<section id="page-inner" class="header-margin">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					@if(Session::has('flash_message'))
						<div class="alert alert-success">
							{{ Session::get('flash_message') }}
						</div>
					@endif
					<h2><i class="fa fa-envelope"></i> Dashboard </h2>
					@include('partials.sub-menu')


				</div>
				{{--<div class="row">--}}
				{{--<div class="col-md-6">--}}
					{{--<h3 class="inline"><i class="fa fa-list-ul"></i> My Requests </h3>--}}
					{{--<div class="filterby">Filter by <select></select></div>--}}


					{{--<p><a href="{{ route('requests') }}">All Requests</a></p>--}}

					{{--<table class="table">--}}
						{{--<tr>--}}
							{{--<th>Product</th>--}}
							{{--<th>Status</th>--}}
							{{--<th>Date/Time</th>--}}
						{{--</tr>--}}
						{{--@foreach($products as $product)--}}
							{{--<tr>--}}
								{{--<td><a href="{{ route('request', $product->id) }}">{{ $product->item_name }}</a></td>--}}
								{{--<td>{{ $product->status }}</td>--}}
								{{--<td>{{ $product->created_at }}</td>--}}
							{{--</tr>--}}
						{{--@endforeach--}}
					{{--</table>--}}
				{{--</div>--}}
				{{--<div class="col-md-6">--}}
					{{--<h3 class="inline"><i class="fa fa-comments-o"></i> My Trips </h3>--}}
					{{--<div class="filterby">Filter by <select></select></div>--}}
					{{--<p><a href="{{ route('trips') }}">All Trips</a></p>--}}
					{{--<table class="table">--}}
						{{--<tr>--}}
							{{--<th>From Country</th>--}}
							{{--<th>From</th>--}}
							{{--<th>To Country</th>--}}
							{{--<th>Upto</th>--}}
							{{--<th>Type</th>--}}
						{{--</tr>--}}
						{{--@foreach($trips as $trip)--}}
							{{--<tr>--}}
								{{--<td>{{ $trip->country }}</td>--}}
								{{--<td>{{ $trip->from_date }}</td>--}}
								{{--<td>{{ $trip->country_to }}</td>--}}
								{{--<td>{{ $trip->upto_date }}</td>--}}
								{{--<td>{{ $trip->trip_type }}</td>--}}
							{{--</tr>--}}
						{{--@endforeach--}}
					{{--</table>--}}
				{{--</div>--}}
				{{--</div>--}}
				{{--<div class="row">--}}
				{{--<div class="col-md-6">--}}
					{{--<h3 class="inline"><i class="fa fa-list-ul"></i> Bids on my projects </h3>--}}
					{{--<div class="filterby">Filter by <select></select></div>--}}
					{{--<p><a href="{{ route('bids') }}">All Bids</a></p>--}}
					{{--<table class="table">--}}
						{{--<tr>--}}
							{{--<th>Product</th>--}}
							{{--<th>User</th>--}}
							{{--<th>Status</th>--}}
							{{--<th>Date/Time</th>--}}
						{{--</tr>--}}
						{{--@foreach($bids as $bid)--}}
							{{--<tr>--}}
								{{--<td><a href="{{ route('request', $bid->product_id) }}">{{ $bid->product->item_name }}</a></td>--}}
								{{--<td>{{ $bid->user->name }}</td>--}}
								{{--<td>{{ $bid->status }}</td>--}}
								{{--<td>{{ $bid->created_at }}</td>--}}
							{{--</tr>--}}
						{{--@endforeach--}}
					{{--</table>--}}

				{{--</div>--}}
				{{--<div class="col-md-6">--}}
					{{--<h3 class="inline"><i class="fa fa-comments-o"></i> Applied on others projects </h3>--}}
					{{--<div class="filterby">Filter by <select></select></div>--}}
					{{--<p><a href="{{ route('applied') }}">All Applied</a></p>--}}
					{{--<table class="table">--}}
						{{--<tr>--}}
							{{--<th>Product</th>--}}
							{{--<th>User</th>--}}
							{{--<th>Status</th>--}}
							{{--<th>Date/Time</th>--}}
						{{--</tr>--}}
						{{--@foreach($applied as $bid)--}}
							{{--<tr>--}}
								{{--<td><a href="{{ route('request', $bid->product_id) }}">{{ $bid->product->item_name }}</a></td>--}}
								{{--<td>{{ $bid->user->name }}</td>--}}
								{{--<td>{{ $bid->status }}</td>--}}
								{{--<td>{{ $bid->created_at }}</td>--}}
							{{--</tr>--}}
						{{--@endforeach--}}
					{{--</table>--}}
				{{--</div>--}}
				{{--</div>--}}
			</div>
		</div>


	</section>

@endsection