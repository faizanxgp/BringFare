@extends('layouts.main')

@section('title')
	Admin Dashboard
@endsection

@section('pageHeading')
	User Dashboard
@endsection

@section('content')
	<section id="page" class="header-margin">
		<div class="container">
			<div class="row">
				<div class="col-md-3 sidebar">

					<div class="search-form">
						<form method="post" action="{{ route('post-search') }}">
							<div class="searchBox">
								<h3>Categories <a class="showHide pull-right"><i class="fa fa-plus-circle"></i></a></h3>
								<div class="options-box" style="display: none;">
									<ul class="nostyle">
										@foreach($categories as $category)
											<li>
												<input type="checkbox" name="category[]" value="{{ $category->id }}"> {{ $category->category }}
											</li>
										@endforeach
									</ul>
								</div>
							</div>
							<div class="searchBox">
								<h3>Purchase From <a class="showHide pull-right"><i class="fa fa-plus-circle"></i></a></h3>
								<div class="options-box" style="display: none;">
									{{ Form::select('country', $countries, $search['country'] or null, ['class' => 'form-control', 'placeholder' => 'Please select...', 'id' => 'country']) }}
								</div>
							</div>

							<div class="searchBox">
								<h3>Deliver in <a class="showHide pull-right"><i class="fa fa-plus-circle"></i></a></h3>
								<div class="options-box" style="display: none;">
									{{ Form::select('d_country', $countries, $search['dcountry'] or null, ['class' => 'form-control', 'placeholder' => 'Please select...', 'id' => 'dcountry']) }}

									<input type="text" class="form-control" name="dcity" value="{{ $search['dcity'] or null }}" placeholder="City" />
								</div>
							</div>

							<div class="searchBox">
								<h3>Price Range <a class="showHide pull-right"><i class="fa fa-plus-circle"></i></a></h3>
								<div class="options-box" style="display: none;">
									<p>
										<label for="amount">Price range:</label>
										<input type="text" id="amount" readonly style="border:0; color:#f6931f; font-weight:bold;">
										<input type="hidden" id="price1" name="price1" value="{{ $search['price1'] or 0 }}" />
										<input type="hidden" id="price2" name="price2" value="{{ $search['price2'] or 1000 }}" />
									</p>

									<div id="slider-range"></div>


								</div>
							</div>

							<div class="searchBox">
								<h3>Deliver before <a class="showHide pull-right"><i class="fa fa-plus-circle"></i></a></h3>
								<div class="options-box" style="display: none;">
									<ul class="nostyle">
										<li>
											<label>Date</label> <input type="text" name="before_date" value="" id="datepicker1">
										</li>

									</ul>
								</div>
							</div>

							<div class="searchBox">
								<h3>Package size <a class="showHide pull-right"><i class="fa fa-plus-circle"></i></a></h3>
								<div class="options-box" style="display: none;">
									<ul class="nostyle">
										<li>
											{{ Form::select('package_size', $package_sizes, null, ['class' => 'form-control', 'placeholder' => 'Please select...']) }}

										</li>

									</ul>
								</div>
							</div>

							<div class="searchBox">
								<h3>Request by people you follow <a class="showHide pull-right"><i class="fa fa-plus-circle"></i></a></h3>
								<div class="options-box" style="display: none;">
									<ul class="nostyle">
										<li>
											<input type="checkbox" name="followers" value="1"> My Followers
										</li>

									</ul>
								</div>
							</div>


							<div class="form-group2">
								{{--<div class="group1">--}}
									{{--<div class="searchType inline">--}}
										{{--<div class="input-group">--}}
											{{--<select name="s_type" class="form-control">--}}
												{{--<option>Request</option>--}}
												{{--<option>Recommendation</option>--}}
												{{--<option>User</option>--}}
												{{--<option>Country</option>--}}
											{{--</select>--}}
										{{--</div>--}}
									{{--</div>--}}
									{{--<div class="searchText inline">--}}
										{{--<div class="input-group">--}}
											{{--<input name="s_text" class="form-control" type="text"/>--}}
										{{--</div>--}}
									{{--</div>--}}

								{{--</div>--}}
								{{--<div class="group2">--}}
									{{--<label> Filter By : </label>--}}
									{{--<div class="input-group inline">--}}
										{{--<select name="s_filter" class="form-control">--}}
											{{--<option>Request</option>--}}
											{{--<option>Recommendation</option>--}}
										{{--</select>--}}
									{{--</div>--}}

									{{--<div class="input-group inline">--}}
										{{--{{ Form::select('s_country', $countries, null, ['class' => 'form-control', 'placeholder' => 'Please select...', 'required']) }}--}}
									{{--</div>--}}


								{{--</div>--}}
								{{--<div class="group3">--}}

									{{--<span class="input-group inline"><input type="checkbox" name="chk_open" aria-label="..."> Open </span><!-- /input-group -->--}}
									{{--<span class="input-group inline"><input type="checkbox" name="chk_process" aria-label="..."> Process </span><!-- /input-group -->--}}
									{{--<span class="input-group inline"><input type="checkbox" name="chk_accepted" aria-label="..."> Accepted </span><!-- /input-group -->--}}
									{{--<span class="input-group inline"><input type="checkbox" name="chk_completed" aria-label="..."> Completed </span><!-- /input-group -->--}}


								{{--</div>--}}

								<div class="searchButton inline">
									<div class="input-group">
										<input class="form-control btn-primary" type="submit" value="Search">
										{{ csrf_field() }}
									</div>
								</div>

							</div>
						</form>
					</div><!-- .search-form -->


					{{--<div class="header">Categories</div>--}}
					{{--<ul class="categories">--}}
						{{--@foreach($categories as $category)--}}
							{{--<li><a href="{{ route('search-category', $category->id) }}">{{ $category->category }}</a></li>--}}
						{{--@endforeach--}}

					{{--</ul>--}}
				</div><!-- .sidebar -->
				<div class="col-md-9">


					<div class="search-results">
						<div class="row">
							@foreach($products as $product)
								<div class="col-md-4">
									<div class="item-card card">
										<div class="card-top">
											<div class="image"><a href="#">@if($product->image) <img src="{{ URL::to('/uploads/products/' . $product->image) }}" alt=""/>@else <img src="{{ URL::to('src/images/items/item1.jpg') }}" alt=""/> @endif</a></div>
											<div class="item-title"><a href="{{ route('request', $product->id) }}">{{ $product->item_name }}</a></div>
											<div class="item-status"><label class="label label-primary">{{ $product->status }}</label></div>

										</div>
										<div class="card-footer">
											<div class="user-img inline"><img src="{{ URL::to('src/images/users/user1.jpg') }}" alt=""/></div>
											<div class="title-img inline">Buy in {{ $product->country }}<br/>at USD {{ $product->price }} <br />Deliver in {{ $product->dcity }}, {{ $product->dcountry }} @if($product->require_date != null) before {{ $product->require_date }}@endif </div>
										</div>
									</div>
								</div>
							@endforeach

							<div class="col-md-4">
								<div class="item-card card">
									<div class="card-top">
										<div class="image"><a href="#"><img src="{{ URL::to('src/images/items/item1.jpg') }}" alt=""/></a></div>
										<div class="item-title">item name</div>
										<div class="item-status"><label class="label label-primary">Open</label></div>
									</div>
									<div class="card-footer">
										<div class="user-img inline"><img src="{{ URL::to('src/images/users/user1.jpg') }}" alt=""/></div>
										<div class="title-img inline">Buy in JAPAN<br/>Willing to pay SGD 1000</div>
									</div>
								</div>
							</div>
						</div>
					</div><!-- .search-results -->

				</div>
			</div>

		</div>


	</section>


@endsection

@section('js')
	<script>
		$(document).ready(function () {
			$('.showHide').click(function (e) {
				e.preventDefault();
				link = $(this).find("i.fa");
				console.log(link);
				if (link.hasClass('fa-plus-circle')) {
					link.addClass('fa-minus-circle');
					link.removeClass('fa-plus-circle');
				} else {
					link.addClass('fa-plus-circle');
					link.removeClass('fa-minus-circle');
				}

				$(this).parent().parent().find("div.options-box").toggle(1000);

			});

			price1 = {{ $search['price1'] or 0 }};
			price2 = {{ $search['price2'] or 1000 }};


			$( "#amount" ).val( "$" + price1 + " - $" + price2 );
		});
	</script>
@endsection