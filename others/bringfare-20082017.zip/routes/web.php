<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//Route::get('/', function () {
//    return view('welcome');
//});

Route::get('/', function () {
    return redirect()->route('home');
})->name('index');

Auth::routes();


# General
Route::get('/home', 'HomeController@index')->name('home');

Route::get('/search', 'HomeController@search')->name('search');
Route::post('/search', 'HomeController@postSearch')->name('post-search');
Route::get('/category/{id}', 'HomeController@getSearchCategory')->name('search-category');

Route::get('/search-trips', 'HomeController@searchTrips')->name('search-trips');
Route::post('/search-trips', 'HomeController@postSearchTrips')->name('post-search-trips');

Route::get('/request/{id?}', 'HomeController@request')->name('request');


# User Actions
Route::get('/dashboard', 'UserController@getHome')->name('dashboard');

Route::get('/requests/create', 'UserController@getRequest')->name('create-request');
Route::post('/requests/add', 'UserController@postRequest')->name('add-request');
Route::get('/requests/create-product/{id}', 'UserController@getRequestDuplicate')->name('create-request-duplicate');

Route::get('/trips/create', 'UserController@getTrip')->name('create-trip');
Route::post('/trips/add', 'UserController@postTrip')->name('add-trip');

Route::post('/user/add-comment', 'UserController@postAddComment')->name('post-comment');
Route::post('/user/edit-comment', 'UserController@postAddComment')->name('edit-comment');


Route::get('/user/requests', 'UserController@getRequests')->name('requests');
Route::get('/user/request/{id}', 'UserController@getRequestEdit')->name('edit-request');
Route::get('/user/request/select/{id}', 'UserController@getRequestSelect')->name('select-request');
Route::get('/user/request/invite/{id}', 'UserController@getRequestInvite')->name('invite-request');
Route::post('/user/request/invite', 'UserController@postRequestInvite')->name('post-invite-request');

Route::get('/user/trips', 'UserController@getTrips')->name('trips');
Route::get('/user/trip/{id}', 'UserController@getTripEdit')->name('edit-trip');

Route::get('/user/inbox', 'UserController@getInbox')->name('inbox');
Route::get('/user/notification', 'UserController@getNotification')->name('notification');

Route::get('/user/bids', 'UserController@getBids')->name('bids');
Route::get('/user/applied', 'UserController@getApplied')->name('applied');

Route::get('/user/discuss/{id}', 'UserController@getDiscuss')->name('discuss');
Route::post('/user/add-discuss', 'UserController@postDiscuss')->name('add-discuss');
Route::post('/user/update-status', 'UserController@postUpdateBidStatus')->name('bid-status');

Route::get('/user/add-rating/{id1}/{id2}', 'UserController@getRating')->name('get-rating');
Route::post('/user/post-rating', 'UserController@postRating')->name('post-rating');

Route::get('/user/wallet', 'UserController@getWallet')->name('wallet');
Route::get('/user/profile/{id?}', 'UserController@getProfile')->name('profile');
Route::get('/user/edit-profile', 'UserController@getEditProfile')->name('edit-profile');
Route::post('/user/update-profile', 'UserController@postEditProfile')->name('update-profile');
Route::get('/user/settings', 'UserController@getSettings')->name('settings');

Route::get('/user/follow/{id}', 'UserController@getFollow')->name('follow');
Route::get('/user/unfollow/{id}', 'UserController@getUnFollow')->name('unfollow');


Route::get('/test', 'UserController@test')->name('test');
Route::get('/test2', 'UserController@test2')->name('test2');

//Auth::routes();

// Admin
Route::get('/users/logout', 'Auth\LoginController@userLogout')->name('user.logout');

Route::prefix('admin')->group(function () {
    Route::get('/login', 'Auth\AdminLoginController@showLoginForm')->name('admin.login');
    Route::post('/login', 'Auth\AdminLoginController@login')->name('admin.login.submit');
    Route::get('/dashboard', 'AdminController@index')->name('admin.dashboard');
    Route::get('/logout', 'Auth\AdminLoginController@logout')->name('admin.logout');

    // Password reset routes
    Route::post('/password/email', 'Auth\AdminForgotPasswordController@sendResetLinkEmail')->name('admin.password.email');
    Route::get('/password/reset', 'Auth\AdminForgotPasswordController@showLinkRequestForm')->name('admin.password.request');
    Route::post('/password/reset', 'Auth\AdminResetPasswordController@reset');
    Route::get('/password/reset/{token}', 'Auth\AdminResetPasswordController@showResetForm')->name('admin.password.reset');

    Route::get('/products', 'AdminController@getProducts')->name('admin.products');
    Route::get('/users', 'AdminController@getUsers')->name('admin.users');
    Route::get('/categories', 'AdminController@getCategories')->name('admin.categories');
    Route::get('/product/{id}', 'AdminController@getProduct')->name('admin.product');
    Route::get('/user/{id}', 'AdminController@getUser')->name('admin.user');
});


Route::group([], function () {

//    Route::get('/', function () {
//        return view('welcome');
//    });


//    Route::get('/main', [
//        'uses' => 'MainController@getIndex',
//        'as' => 'index-page'
//    ]);

    #->middleware('auth');
    #magic

    /* General */


    /* Common */
    Route::get('/error', [
        'uses' => 'HomeController@getErrorPage',
        'as' => 'error'
    ]);


});

#Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

//Route::get('login/github', 'SocialAuthController@redirectToProvider');
//Route::get('login/github/callback', 'SocialAuthController@handleProviderCallback');
//
//Route::get('auth/{provider}', 'Auth\AuthController@redirectToProvider');
//Route::get('auth/{provider}/callback', 'Auth\AuthController@handleProviderCallback');


Route::get('auth/{provider}', 'Auth\RegisterController@redirectToProvider');
Route::get('auth/{provider}/callback', 'Auth\RegisterController@handleProviderCallback');